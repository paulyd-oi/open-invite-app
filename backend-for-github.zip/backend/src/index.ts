import "@vibecodeapp/proxy"; // DO NOT REMOVE OTHERWISE VIBECODE PROXY WILL NOT WORK
import { serve } from "@hono/node-server";
import { Hono } from "hono";
import { cors } from "hono/cors";
import { logger } from "hono/logger";
import { serveStatic } from "@hono/node-server/serve-static";

import { auth } from "./auth";
import { env } from "./env";
import { uploadRouter } from "./routes/upload";
import { sampleRouter } from "./routes/sample";
import { eventsRouter } from "./routes/events";
import { friendsRouter } from "./routes/friends";
import { groupsRouter } from "./routes/groups";
import { notificationsRouter } from "./routes/notifications";
import { profileRouter } from "./routes/profile";
import { placesRouter } from "./routes/places";
import { blockedRouter } from "./routes/blocked";
import { birthdaysRouter } from "./routes/birthdays";
import { workScheduleRouter } from "./routes/workSchedule";
import { friendNotesRouter } from "./routes/friendNotes";
import { subscriptionRouter } from "./routes/subscription";
import { onboardingRouter } from "./routes/onboarding";
import { referralRouter } from "./routes/referral";
import { eventRequestsRouter } from "./routes/eventRequests";
import { type AppType } from "./types";
import { db } from "./db";

// AppType context adds user and session to the context, will be null if the user or session is null
const app = new Hono<AppType>();

console.log("🔧 Initializing Hono application...");
app.use("*", logger());
app.use(
  "/*",
  cors({
    origin: (origin) => origin || "*", // Allow the requesting origin or fallback to *
    credentials: true,
    allowHeaders: ["Content-Type", "Authorization", "expo-origin"], // expo-origin is required for Better Auth Expo plugin
    allowMethods: ["GET", "POST", "PUT", "DELETE", "OPTIONS"],
  }),
);

/** Authentication middleware
 * Extracts session from request headers and attaches user/session to context
 * All routes can access c.get("user") and c.get("session")
 */
app.use("*", async (c, next) => {
  const session = await auth.api.getSession({ headers: c.req.raw.headers });
  c.set("user", session?.user ?? null); // type: typeof auth.$Infer.Session.user | null
  c.set("session", session?.session ?? null); // type: typeof auth.$Infer.Session.session | null
  return next();
});

// Better Auth handler
// Handles all authentication endpoints: /api/auth/sign-in, /api/auth/sign-up, etc.
console.log("🔐 Mounting Better Auth handler at /api/auth/*");
app.on(["GET", "POST"], "/api/auth/*", async (c) => {
  const request = c.req.raw;
  console.log(`🔐 [Auth Request] ${request.method} ${c.req.path}`);

  // Log request body for sign-up attempts (without password)
  if (c.req.path.includes("sign-up")) {
    try {
      const clonedReq = request.clone();
      const body = await clonedReq.json();
      console.log(`🔐 [Sign Up Attempt] Email: ${body.email}, Name: ${body.name}`);
    } catch (e) {
      console.log(`🔐 [Sign Up] Could not parse request body`);
    }
  }

  try {
    // Workaround for Expo/React Native: native apps don't send Origin header,
    // but the expo client plugin sends expo-origin instead. We need to create
    // a new request with the origin header set from expo-origin.
    const expoOrigin = request.headers.get("expo-origin");
    if (!request.headers.get("origin") && expoOrigin) {
      const headers = new Headers(request.headers);
      headers.set("origin", expoOrigin);
      const modifiedRequest = new Request(request, { headers });
      const response = await auth.handler(modifiedRequest);
      console.log(`🔐 [Auth Response] Status: ${response.status}`);
      if (response.status >= 400) {
        const clonedRes = response.clone();
        try {
          const errBody = await clonedRes.json();
          console.log(`🔐 [Auth Error Body] ${JSON.stringify(errBody)}`);
        } catch (e) {}
      }
      return response;
    }
    const response = await auth.handler(request);
    console.log(`🔐 [Auth Response] Status: ${response.status}`);
    if (response.status >= 400) {
      const clonedRes = response.clone();
      try {
        const errBody = await clonedRes.json();
        console.log(`🔐 [Auth Error Body] ${JSON.stringify(errBody)}`);
      } catch (e) {}
    }
    return response;
  } catch (error: any) {
    console.error(`🔐 [Auth Error] ${error?.message || error}`);
    console.error(`🔐 [Auth Error Stack] ${error?.stack}`);
    return c.json({ error: error?.message || "Authentication error" }, 500);
  }
});

// Serve uploaded images statically
// Files in uploads/ directory are accessible at /uploads/* URLs
console.log("📁 Serving static files from uploads/ directory");
app.use("/uploads/*", serveStatic({ root: "./" }));

// Mount route modules
console.log("📤 Mounting upload routes at /api/upload");
app.route("/api/upload", uploadRouter);

console.log("📝 Mounting sample routes at /api/sample");
app.route("/api/sample", sampleRouter);

// Open Invite API routes
console.log("📅 Mounting events routes at /api/events");
app.route("/api/events", eventsRouter);

console.log("👥 Mounting friends routes at /api/friends");
app.route("/api/friends", friendsRouter);

console.log("📁 Mounting groups routes at /api/groups");
app.route("/api/groups", groupsRouter);

console.log("🔔 Mounting notifications routes at /api/notifications");
app.route("/api/notifications", notificationsRouter);

console.log("👤 Mounting profile routes at /api/profile");
app.route("/api/profile", profileRouter);

console.log("📍 Mounting places routes at /api/places");
app.route("/api/places", placesRouter);

console.log("🚫 Mounting blocked routes at /api/blocked");
app.route("/api/blocked", blockedRouter);

console.log("🎂 Mounting birthdays routes at /api/birthdays");
app.route("/api/birthdays", birthdaysRouter);

console.log("📅 Mounting work schedule routes at /api/work-schedule");
app.route("/api/work-schedule", workScheduleRouter);

console.log("📝 Mounting friend notes routes at /api/friends");
app.route("/api/friends", friendNotesRouter);

console.log("💳 Mounting subscription routes at /api/subscription");
app.route("/api/subscription", subscriptionRouter);

console.log("🎓 Mounting onboarding routes at /api/onboarding");
app.route("/api/onboarding", onboardingRouter);

console.log("🎁 Mounting referral routes at /api/referral");
app.route("/api/referral", referralRouter);

console.log("📨 Mounting event requests routes at /api/event-requests");
app.route("/api/event-requests", eventRequestsRouter);

// Email verification success page
// After users click the verification link, they are redirected here
app.get("/", (c) => {
  const html = `
    <!DOCTYPE html>
    <html lang="en">
    <head>
      <meta charset="UTF-8">
      <meta name="viewport" content="width=device-width, initial-scale=1.0">
      <title>Email Verified - Open Invite</title>
      <style>
        * { margin: 0; padding: 0; box-sizing: border-box; }
        body {
          font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, Helvetica, Arial, sans-serif;
          background: linear-gradient(135deg, #1a1a2e 0%, #16213e 50%, #0f3460 100%);
          min-height: 100vh;
          display: flex;
          align-items: center;
          justify-content: center;
          padding: 20px;
        }
        .container {
          background: rgba(255, 255, 255, 0.95);
          border-radius: 24px;
          padding: 48px 40px;
          max-width: 420px;
          width: 100%;
          text-align: center;
          box-shadow: 0 25px 50px -12px rgba(0, 0, 0, 0.25);
        }
        .icon {
          width: 80px;
          height: 80px;
          background: linear-gradient(135deg, #10b981 0%, #059669 100%);
          border-radius: 50%;
          display: flex;
          align-items: center;
          justify-content: center;
          margin: 0 auto 24px;
        }
        .icon svg {
          width: 40px;
          height: 40px;
          color: white;
        }
        h1 {
          color: #1f2937;
          font-size: 28px;
          font-weight: 700;
          margin-bottom: 12px;
        }
        p {
          color: #6b7280;
          font-size: 16px;
          line-height: 1.6;
          margin-bottom: 32px;
        }
        .button {
          display: inline-block;
          background: linear-gradient(135deg, #FF6B4A 0%, #FF8A6B 100%);
          color: white;
          text-decoration: none;
          padding: 16px 32px;
          border-radius: 12px;
          font-weight: 600;
          font-size: 16px;
          transition: transform 0.2s, box-shadow 0.2s;
        }
        .button:hover {
          transform: translateY(-2px);
          box-shadow: 0 10px 20px -5px rgba(255, 107, 74, 0.4);
        }
        .footer {
          margin-top: 32px;
          color: #9ca3af;
          font-size: 14px;
        }
      </style>
    </head>
    <body>
      <div class="container">
        <div class="icon">
          <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke="currentColor" stroke-width="3">
            <path stroke-linecap="round" stroke-linejoin="round" d="M5 13l4 4L19 7" />
          </svg>
        </div>
        <h1>Email Verified!</h1>
        <p>Your email has been successfully verified. You can now sign in to Open Invite and start connecting with friends.</p>
        <a href="vibecode://" class="button">Open App</a>
        <p class="footer">Open Invite - See what your friends are up to</p>
      </div>
    </body>
    </html>
  `;
  return c.html(html);
});

// Health check endpoint
// Used by load balancers and monitoring tools to verify service is running
app.get("/health", (c) => {
  console.log("💚 Health check requested");
  return c.json({ status: "ok" });
});

// Start the server
console.log("⚙️  Starting server...");
const server = serve({ fetch: app.fetch, port: Number(env.PORT) }, () => {
  console.log("━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━");
  console.log(`📍 Environment: ${env.NODE_ENV}`);
  console.log(`🚀 Server is running on port ${env.PORT}`);
  console.log(`🔗 Base URL: http://localhost:${env.PORT}`);
  console.log("━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━");
  console.log("\n📚 Available endpoints:");
  console.log("  🔐 Auth:     /api/auth/*");
  console.log("  📤 Upload:   POST /api/upload/image");
  console.log("  📝 Sample:   GET/POST /api/sample");
  console.log("  💚 Health:   GET /health");
  console.log("━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━\n");
});

// Graceful shutdown
const shutdown = async () => {
  console.log("Shutting down server...");
  await db.$disconnect();
  console.log("Successfully shutdown server");
  server.close();
  process.exit(0);
};

// Handle SIGINT (ctrl+c).
process.on("SIGINT", async () => {
  console.log("SIGINT received. Cleaning up...");
  await shutdown();
});

// Handle SIGTERM (normal shutdown).
process.on("SIGTERM", async () => {
  console.log("SIGTERM received. Cleaning up...");
  await shutdown();
});
