import { Hono } from "hono";
import { db } from "../db";
import { type AppType } from "../types";
import {
  sendFriendRequestSchema,
  updateFriendRequestSchema,
  blockFriendRequestSchema,
} from "@/shared/contracts";
import { nanoid } from "nanoid";
import { getBlockedUserIds, getBlockedByUserIds, isIdentifierBlocked } from "./blocked";

export const friendsRouter = new Hono<AppType>();

// Helper to serialize friendship
const serializeFriendship = (friendship: {
  id: string;
  friendId: string;
  isBlocked: boolean;
  createdAt: Date;
  friend: {
    id: string;
    name: string | null;
    email: string;
    image: string | null;
    Profile?: { handle: string; bio: string | null; avatarUrl: string | null } | null;
  };
  groupMemberships?: Array<{
    groupId: string;
    group: { id: string; name: string; color: string };
  }>;
}) => ({
  ...friendship,
  createdAt: friendship.createdAt.toISOString(),
});

// GET /api/friends - Get all friends
friendsRouter.get("/", async (c) => {
  const user = c.get("user");
  if (!user) {
    return c.json({ error: "Unauthorized" }, 401);
  }

  // Get blocked user IDs (both directions)
  const [blockedByMe, blockedMe] = await Promise.all([
    getBlockedUserIds(user.id),
    getBlockedByUserIds(user.id),
  ]);
  const allBlockedIds = [...new Set([...blockedByMe, ...blockedMe])];

  const friendships = await db.friendship.findMany({
    where: {
      userId: user.id,
      friendId: { notIn: allBlockedIds }, // Exclude blocked users
    },
    include: {
      friend: {
        select: {
          id: true,
          name: true,
          email: true,
          image: true,
          Profile: true,
        },
      },
      groupMemberships: {
        include: {
          group: { select: { id: true, name: true, color: true } },
        },
      },
    },
    orderBy: { friend: { name: "asc" } },
  });

  return c.json({ friends: friendships.map(serializeFriendship) });
});

// GET /api/friends/requests - Get pending friend requests
friendsRouter.get("/requests", async (c) => {
  const user = c.get("user");
  if (!user) {
    return c.json({ error: "Unauthorized" }, 401);
  }

  // Get blocked user IDs (both directions)
  const [blockedByMe, blockedMe] = await Promise.all([
    getBlockedUserIds(user.id),
    getBlockedByUserIds(user.id),
  ]);
  const allBlockedIds = [...new Set([...blockedByMe, ...blockedMe])];

  const [received, sent] = await Promise.all([
    db.friendRequest.findMany({
      where: {
        receiverId: user.id,
        status: "pending",
        senderId: { notIn: allBlockedIds }, // Exclude requests from blocked users
      },
      include: {
        sender: {
          select: {
            id: true,
            name: true,
            email: true,
            image: true,
            Profile: true,
          },
        },
      },
      orderBy: { createdAt: "desc" },
    }),
    db.friendRequest.findMany({
      where: {
        senderId: user.id,
        status: "pending",
        receiverId: { notIn: allBlockedIds }, // Exclude requests to blocked users
      },
      include: {
        receiver: {
          select: {
            id: true,
            name: true,
            email: true,
            image: true,
            Profile: true,
          },
        },
      },
      orderBy: { createdAt: "desc" },
    }),
  ]);

  return c.json({
    received: received.map((r) => ({
      ...r,
      createdAt: r.createdAt.toISOString(),
    })),
    sent: sent.map((s) => ({
      ...s,
      createdAt: s.createdAt.toISOString(),
    })),
  });
});

// POST /api/friends/request - Send friend request
friendsRouter.post("/request", async (c) => {
  const user = c.get("user");
  if (!user) {
    return c.json({ error: "Unauthorized" }, 401);
  }

  const body = await c.req.json();
  const parsed = sendFriendRequestSchema.safeParse(body);

  if (!parsed.success) {
    return c.json({ error: "Invalid request", details: parsed.error }, 400);
  }

  // Check if the email/phone is blocked by us
  const isBlocked = await isIdentifierBlocked(user.id, parsed.data.email, parsed.data.phone);
  if (isBlocked) {
    // Don't reveal they're blocked - just say user not found
    return c.json({ success: false, message: "User not found. They may need to sign up first." });
  }

  // Find target user by email or phone
  let targetUser = null;
  if (parsed.data.email) {
    targetUser = await db.user.findUnique({
      where: { email: parsed.data.email },
    });
  } else if (parsed.data.phone) {
    // Normalize phone number (remove spaces, dashes, etc.)
    const normalizedPhone = parsed.data.phone.replace(/[\s\-\(\)]/g, "");
    targetUser = await db.user.findFirst({
      where: { phone: normalizedPhone },
    });
  }

  if (!targetUser) {
    return c.json({ success: false, message: "User not found. They may need to sign up first." });
  }

  if (targetUser.id === user.id) {
    return c.json({ success: false, message: "Cannot send friend request to yourself" });
  }

  // Check if either user has blocked the other
  const [iBlockedThem, theyBlockedMe] = await Promise.all([
    getBlockedUserIds(user.id),
    getBlockedByUserIds(user.id),
  ]);

  if (iBlockedThem.includes(targetUser.id)) {
    // Don't reveal they're blocked - say user not found
    return c.json({ success: false, message: "User not found. They may need to sign up first." });
  }

  if (theyBlockedMe.includes(targetUser.id)) {
    // If they blocked us, silently fail (they don't know we tried)
    // Return success but don't actually send the request
    return c.json({ success: true, message: "Friend request sent!" });
  }

  // Check if already friends
  const existingFriendship = await db.friendship.findUnique({
    where: { userId_friendId: { userId: user.id, friendId: targetUser.id } },
  });

  if (existingFriendship) {
    return c.json({ success: false, message: "Already friends" });
  }

  // Check if request already exists
  const existingRequest = await db.friendRequest.findFirst({
    where: {
      OR: [
        { senderId: user.id, receiverId: targetUser.id },
        { senderId: targetUser.id, receiverId: user.id },
      ],
      status: "pending",
    },
  });

  if (existingRequest) {
    // If they sent us a request, auto-accept
    if (existingRequest.senderId === targetUser.id) {
      await db.friendRequest.update({
        where: { id: existingRequest.id },
        data: { status: "accepted" },
      });

      // Create bidirectional friendship
      await db.friendship.createMany({
        data: [
          { userId: user.id, friendId: targetUser.id },
          { userId: targetUser.id, friendId: user.id },
        ],
      });

      return c.json({ success: true, message: "Friend request accepted - you're now friends!" });
    }

    return c.json({ success: false, message: "Friend request already sent" });
  }

  // Create friend request
  const request = await db.friendRequest.create({
    data: {
      senderId: user.id,
      receiverId: targetUser.id,
    },
    include: {
      receiver: {
        select: { id: true, name: true, email: true, image: true },
      },
    },
  });

  // Notify target user
  await db.notification.create({
    data: {
      userId: targetUser.id,
      type: "friend_request",
      title: "Friend Request",
      body: `${user.name ?? user.email} wants to be your friend`,
      data: JSON.stringify({ requestId: request.id }),
    },
  });

  return c.json({
    success: true,
    request: { ...request, createdAt: request.createdAt.toISOString() },
  });
});

// PUT /api/friends/request/:id - Accept/reject friend request
friendsRouter.put("/request/:id", async (c) => {
  const user = c.get("user");
  if (!user) {
    return c.json({ error: "Unauthorized" }, 401);
  }

  const requestId = c.req.param("id");
  const body = await c.req.json();
  const parsed = updateFriendRequestSchema.safeParse(body);

  if (!parsed.success) {
    return c.json({ error: "Invalid request", details: parsed.error }, 400);
  }

  // Check if request exists and is for this user
  const request = await db.friendRequest.findFirst({
    where: { id: requestId, receiverId: user.id, status: "pending" },
    include: { sender: true },
  });

  if (!request) {
    return c.json({ error: "Request not found" }, 404);
  }

  await db.friendRequest.update({
    where: { id: requestId },
    data: { status: parsed.data.status },
  });

  if (parsed.data.status === "accepted") {
    // Create bidirectional friendship
    const friendships = await db.$transaction([
      db.friendship.create({
        data: { userId: user.id, friendId: request.senderId },
      }),
      db.friendship.create({
        data: { userId: request.senderId, friendId: user.id },
      }),
    ]);

    // Notify sender
    await db.notification.create({
      data: {
        userId: request.senderId,
        type: "request_accepted",
        title: "Friend Request Accepted",
        body: `${user.name ?? user.email} accepted your friend request!`,
        data: JSON.stringify({ userId: user.id }),
      },
    });

    // Return the friendship ID for the accepting user (first one in the transaction)
    return c.json({
      success: true,
      friendshipId: friendships[0].id,
      friend: {
        id: request.sender?.id,
        name: request.sender?.name,
        image: request.sender?.image,
      }
    });
  }

  return c.json({ success: true });
});

// DELETE /api/friends/:id - Remove friend (id is friendshipId)
friendsRouter.delete("/:id", async (c) => {
  const user = c.get("user");
  if (!user) {
    return c.json({ error: "Unauthorized" }, 401);
  }

  const friendshipId = c.req.param("id");

  // Get the friendship to find the friend
  const friendship = await db.friendship.findFirst({
    where: { id: friendshipId, userId: user.id },
  });

  if (!friendship) {
    return c.json({ error: "Friendship not found" }, 404);
  }

  // Delete both sides of the friendship
  await db.friendship.deleteMany({
    where: {
      OR: [
        { userId: user.id, friendId: friendship.friendId },
        { userId: friendship.friendId, friendId: user.id },
      ],
    },
  });

  return c.json({ success: true });
});

// PUT /api/friends/:id/block - Block/unblock friend
friendsRouter.put("/:id/block", async (c) => {
  const user = c.get("user");
  if (!user) {
    return c.json({ error: "Unauthorized" }, 401);
  }

  const friendshipId = c.req.param("id");
  const body = await c.req.json();
  const parsed = blockFriendRequestSchema.safeParse(body);

  if (!parsed.success) {
    return c.json({ error: "Invalid request", details: parsed.error }, 400);
  }

  // Update the friendship
  const friendship = await db.friendship.updateMany({
    where: { id: friendshipId, userId: user.id },
    data: { isBlocked: parsed.data.blocked },
  });

  if (friendship.count === 0) {
    return c.json({ error: "Friendship not found" }, 404);
  }

  return c.json({ success: true });
});

// GET /api/friends/:id/events - Get friend's visible events
friendsRouter.get("/:id/events", async (c) => {
  const user = c.get("user");
  if (!user) {
    return c.json({ error: "Unauthorized" }, 401);
  }

  const friendshipId = c.req.param("id");

  // Get the friendship and verify access
  const friendship = await db.friendship.findFirst({
    where: { id: friendshipId, userId: user.id, isBlocked: false },
    include: {
      friend: {
        select: { id: true, name: true, email: true, image: true, Profile: true },
      },
      groupMemberships: true,
    },
  });

  if (!friendship) {
    return c.json({ error: "Friend not found" }, 404);
  }

  // Get friend's events that this user can see
  const groupIds = friendship.groupMemberships.map((m) => m.groupId);

  const events = await db.event.findMany({
    where: {
      userId: friendship.friendId,
      OR: [
        { visibility: "all_friends" },
        {
          visibility: "specific_groups",
          groupVisibility: {
            some: { groupId: { in: groupIds } },
          },
        },
      ],
    },
    include: {
      user: { select: { id: true, name: true, email: true, image: true } },
      groupVisibility: {
        include: {
          group: { select: { id: true, name: true, color: true } },
        },
      },
      joinRequests: {
        where: { userId: user.id },
        include: {
          user: { select: { id: true, name: true, image: true } },
        },
      },
    },
    orderBy: { startTime: "asc" },
  });

  return c.json({
    events: events.map((e) => ({
      ...e,
      startTime: e.startTime.toISOString(),
      endTime: e.endTime?.toISOString() ?? null,
      createdAt: e.createdAt.toISOString(),
      updatedAt: e.updatedAt.toISOString(),
    })),
    friend: friendship.friend,
  });
});

// POST /api/friends/test - Create a test friend for beta testing
friendsRouter.post("/test", async (c) => {
  const user = c.get("user");
  if (!user) {
    return c.json({ error: "Unauthorized" }, 401);
  }

  const body = await c.req.json();
  const { name, email } = body;

  if (!name) {
    return c.json({ error: "Name is required" }, 400);
  }

  // Generate a unique email if not provided
  const testEmail = email || `test-${nanoid(8)}@testfriend.local`;

  // Check if test user already exists
  let testUser = await db.user.findUnique({
    where: { email: testEmail },
  });

  if (!testUser) {
    // Create the test user
    testUser = await db.user.create({
      data: {
        id: nanoid(),
        email: testEmail,
        name,
        emailVerified: true,
      },
    });

    // Create account for the test user
    await db.account.create({
      data: {
        id: nanoid(),
        accountId: testUser.id,
        providerId: "credential",
        userId: testUser.id,
      },
    });
  }

  // Check if already friends
  const existingFriendship = await db.friendship.findUnique({
    where: { userId_friendId: { userId: user.id, friendId: testUser.id } },
  });

  if (existingFriendship) {
    return c.json({
      success: false,
      message: "Already friends with this test user",
      testUser: {
        id: testUser.id,
        name: testUser.name,
        email: testUser.email,
      }
    });
  }

  // Create bidirectional friendship directly (skip friend request for testing)
  await db.friendship.createMany({
    data: [
      { id: nanoid(), userId: user.id, friendId: testUser.id },
      { id: nanoid(), userId: testUser.id, friendId: user.id },
    ],
  });

  return c.json({
    success: true,
    message: `Test friend "${name}" created and added!`,
    testUser: {
      id: testUser.id,
      name: testUser.name,
      email: testUser.email,
    },
  });
});

// POST /api/friends/test/:id/event - Create a test event for a test friend
friendsRouter.post("/test/:id/event", async (c) => {
  const user = c.get("user");
  if (!user) {
    return c.json({ error: "Unauthorized" }, 401);
  }

  const testUserId = c.req.param("id");
  const body = await c.req.json();
  const { title, description, location, emoji, startTime } = body;

  if (!title) {
    return c.json({ error: "Title is required" }, 400);
  }

  // Verify the test user exists and is a friend
  const friendship = await db.friendship.findFirst({
    where: { userId: user.id, friendId: testUserId },
  });

  if (!friendship) {
    return c.json({ error: "Test user is not your friend" }, 400);
  }

  // Create event for the test friend
  const event = await db.event.create({
    data: {
      id: nanoid(),
      title,
      description: description || null,
      location: location || null,
      emoji: emoji || "📅",
      startTime: startTime ? new Date(startTime) : new Date(Date.now() + 86400000), // Default to tomorrow
      visibility: "all_friends",
      userId: testUserId,
    },
  });

  return c.json({
    success: true,
    message: `Test event "${title}" created!`,
    event: {
      ...event,
      startTime: event.startTime.toISOString(),
      createdAt: event.createdAt.toISOString(),
      updatedAt: event.updatedAt.toISOString(),
    },
  });
});

// POST /api/friends/test/:id/request - Send a test friend request from a test user to yourself
friendsRouter.post("/test/:id/request", async (c) => {
  const user = c.get("user");
  if (!user) {
    return c.json({ error: "Unauthorized" }, 401);
  }

  const testUserId = c.req.param("id");

  // Verify the test user exists
  const testUser = await db.user.findUnique({
    where: { id: testUserId },
  });

  if (!testUser) {
    return c.json({ error: "Test user not found" }, 404);
  }

  // Verify it's a test user (has @testfriend.local email)
  if (!testUser.email.includes("@testfriend.local")) {
    return c.json({ error: "Only test users can send test friend requests" }, 400);
  }

  // First, delete any existing friendship between you and this test user
  await db.friendship.deleteMany({
    where: {
      OR: [
        { userId: user.id, friendId: testUserId },
        { userId: testUserId, friendId: user.id },
      ],
    },
  });

  // Delete any existing friend requests
  await db.friendRequest.deleteMany({
    where: {
      OR: [
        { senderId: testUserId, receiverId: user.id },
        { senderId: user.id, receiverId: testUserId },
      ],
    },
  });

  // Create a friend request from the test user to the current user
  const request = await db.friendRequest.create({
    data: {
      senderId: testUserId,
      receiverId: user.id,
    },
    include: {
      sender: {
        select: { id: true, name: true, email: true, image: true },
      },
    },
  });

  // Create a notification for the user
  await db.notification.create({
    data: {
      userId: user.id,
      type: "friend_request",
      title: "Friend Request",
      body: `${testUser.name ?? testUser.email} wants to be your friend`,
      data: JSON.stringify({ requestId: request.id }),
    },
  });

  return c.json({
    success: true,
    message: `${testUser.name} sent you a friend request!`,
    request: { ...request, createdAt: request.createdAt.toISOString() },
  });
});

// GET /api/friends/suggestions - Get friend suggestions (people you may know)
friendsRouter.get("/suggestions", async (c) => {
  const user = c.get("user");
  if (!user) {
    return c.json({ error: "Unauthorized" }, 401);
  }

  // Get blocked user IDs (both directions)
  const [blockedByMe, blockedMe] = await Promise.all([
    getBlockedUserIds(user.id),
    getBlockedByUserIds(user.id),
  ]);
  const allBlockedIds = [...new Set([...blockedByMe, ...blockedMe])];

  // Get my friends
  const myFriendships = await db.friendship.findMany({
    where: { userId: user.id },
    select: { friendId: true },
  });
  const myFriendIds = new Set(myFriendships.map((f) => f.friendId));

  // Get pending friend requests I've sent or received
  const pendingRequests = await db.friendRequest.findMany({
    where: {
      OR: [{ senderId: user.id }, { receiverId: user.id }],
      status: "pending",
    },
    select: { senderId: true, receiverId: true },
  });
  const pendingUserIds = new Set(
    pendingRequests.flatMap((r) => [r.senderId, r.receiverId])
  );

  // Get friends-of-friends (potential suggestions)
  const friendsOfFriends = await db.friendship.findMany({
    where: {
      userId: { in: Array.from(myFriendIds) },
      friendId: {
        notIn: [
          user.id,
          ...Array.from(myFriendIds),
          ...Array.from(pendingUserIds),
          ...allBlockedIds,
        ],
      },
    },
    include: {
      friend: {
        select: {
          id: true,
          name: true,
          email: true,
          image: true,
          Profile: {
            select: {
              handle: true,
              bio: true,
              avatarUrl: true,
            },
          },
        },
      },
      user: {
        select: {
          id: true,
          name: true,
          image: true,
        },
      },
    },
  });

  // Count mutual friends for each suggested person
  const suggestionMap: Record<
    string,
    {
      user: (typeof friendsOfFriends)[0]["friend"];
      mutualFriends: Array<{ id: string; name: string | null; image: string | null }>;
    }
  > = {};

  for (const fof of friendsOfFriends) {
    const suggestedUserId = fof.friendId;
    if (!suggestionMap[suggestedUserId]) {
      suggestionMap[suggestedUserId] = {
        user: fof.friend,
        mutualFriends: [],
      };
    }
    // The 'user' in this friendship is our mutual friend
    suggestionMap[suggestedUserId].mutualFriends.push({
      id: fof.user.id,
      name: fof.user.name,
      image: fof.user.image,
    });
  }

  // Convert to array and sort by number of mutual friends
  const suggestions = Object.values(suggestionMap)
    .map((s) => ({
      user: s.user,
      mutualFriends: s.mutualFriends,
      mutualFriendCount: s.mutualFriends.length,
    }))
    .sort((a, b) => b.mutualFriendCount - a.mutualFriendCount)
    .slice(0, 20); // Limit to top 20 suggestions

  return c.json({ suggestions });
});

// GET /api/friends/:id/mutual - Get mutual friends with another user
friendsRouter.get("/:id/mutual", async (c) => {
  const user = c.get("user");
  if (!user) {
    return c.json({ error: "Unauthorized" }, 401);
  }

  const targetUserId = c.req.param("id");

  // Get my friends
  const myFriendships = await db.friendship.findMany({
    where: { userId: user.id },
    select: { friendId: true },
  });
  const myFriendIds = new Set(myFriendships.map((f) => f.friendId));

  // Get target user's friends
  const targetFriendships = await db.friendship.findMany({
    where: { userId: targetUserId },
    select: { friendId: true },
  });
  const targetFriendIds = new Set(targetFriendships.map((f) => f.friendId));

  // Find mutual friend IDs (intersection)
  const mutualFriendIds = [...myFriendIds].filter((id) => targetFriendIds.has(id));

  // Fetch mutual friend details
  const mutualFriends = await db.user.findMany({
    where: { id: { in: mutualFriendIds } },
    select: {
      id: true,
      name: true,
      email: true,
      image: true,
      Profile: {
        select: {
          handle: true,
          bio: true,
          avatarUrl: true,
          calendarBio: true,
        },
      },
    },
  });

  return c.json({
    mutualFriends: mutualFriends.map((f) => ({
      ...f,
      Profile: f.Profile ?? undefined,
    })),
    count: mutualFriends.length,
  });
});
