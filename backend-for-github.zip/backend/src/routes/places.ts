import { Hono } from "hono";
import { type AppType } from "../types";

export const placesRouter = new Hono<AppType>();

// Google Places API key from environment
const GOOGLE_API_KEY = process.env.EXPO_PUBLIC_GOOGLE_PLACES_API_KEY || "";

// Common place categories for smart suggestions
const PLACE_CATEGORIES = [
  { keywords: ["coffee", "cafe", "starbucks"], suggestions: ["Starbucks", "Coffee Shop", "Café", "Coffee Bean", "Peet's Coffee"] },
  { keywords: ["restaurant", "food", "eat", "dinner", "lunch", "breakfast"], suggestions: ["Restaurant", "Diner", "Bistro", "Eatery"] },
  { keywords: ["bar", "pub", "drinks", "beer", "wine"], suggestions: ["Bar", "Pub", "Sports Bar", "Wine Bar", "Brewery"] },
  { keywords: ["gym", "fitness", "workout", "exercise"], suggestions: ["Gym", "Fitness Center", "24 Hour Fitness", "LA Fitness", "CrossFit"] },
  { keywords: ["park", "outdoor", "nature"], suggestions: ["Park", "National Park", "State Park", "Dog Park", "Playground"] },
  { keywords: ["beach", "ocean", "sand"], suggestions: ["Beach", "Beach Park", "Boardwalk"] },
  { keywords: ["mall", "shopping", "store"], suggestions: ["Shopping Mall", "Shopping Center", "Outlet Mall", "Target", "Walmart"] },
  { keywords: ["movie", "cinema", "theater", "theatre"], suggestions: ["Movie Theater", "AMC", "Regal Cinema", "Cinemark"] },
  { keywords: ["bowling"], suggestions: ["Bowling Alley", "Bowl", "Lanes"] },
  { keywords: ["golf"], suggestions: ["Golf Course", "Golf Club", "Driving Range", "Mini Golf"] },
  { keywords: ["library"], suggestions: ["Library", "Public Library"] },
  { keywords: ["museum"], suggestions: ["Museum", "Art Museum", "History Museum", "Science Museum"] },
  { keywords: ["zoo"], suggestions: ["Zoo", "Safari Park", "Animal Park"] },
  { keywords: ["aquarium"], suggestions: ["Aquarium", "Sea World", "Marine Park"] },
  { keywords: ["hotel", "motel"], suggestions: ["Hotel", "Inn", "Marriott", "Hilton", "Hyatt"] },
  { keywords: ["airport"], suggestions: ["Airport", "International Airport"] },
  { keywords: ["hospital", "medical", "doctor"], suggestions: ["Hospital", "Medical Center", "Urgent Care", "Clinic"] },
  { keywords: ["school", "university", "college"], suggestions: ["School", "University", "College", "High School"] },
  { keywords: ["church", "temple", "mosque", "synagogue"], suggestions: ["Church", "Temple", "Mosque", "Synagogue"] },
  { keywords: ["pizza"], suggestions: ["Pizza Hut", "Domino's", "Papa John's", "Pizzeria"] },
  { keywords: ["burger", "mcdonald", "wendy", "fast food"], suggestions: ["McDonald's", "Burger King", "Wendy's", "In-N-Out", "Five Guys"] },
  { keywords: ["taco", "mexican"], suggestions: ["Taco Bell", "Chipotle", "Mexican Restaurant", "Taqueria"] },
  { keywords: ["chinese", "asian"], suggestions: ["Chinese Restaurant", "Panda Express", "Asian Restaurant"] },
  { keywords: ["sushi", "japanese"], suggestions: ["Sushi Restaurant", "Japanese Restaurant", "Ramen Shop"] },
  { keywords: ["italian", "pasta"], suggestions: ["Italian Restaurant", "Olive Garden", "Pasta House"] },
  { keywords: ["indian"], suggestions: ["Indian Restaurant", "Curry House"] },
  { keywords: ["thai"], suggestions: ["Thai Restaurant"] },
  { keywords: ["ice cream", "dessert"], suggestions: ["Ice Cream Shop", "Baskin Robbins", "Cold Stone", "Dairy Queen"] },
  { keywords: ["bakery", "bread", "pastry"], suggestions: ["Bakery", "Donut Shop", "Pastry Shop"] },
  { keywords: ["smoothie", "juice", "jamba"], suggestions: ["Jamba Juice", "Smoothie King", "Juice Bar"] },
  { keywords: ["spa", "massage"], suggestions: ["Spa", "Massage", "Day Spa", "Wellness Center"] },
  { keywords: ["salon", "haircut", "barber"], suggestions: ["Hair Salon", "Barber Shop", "Great Clips", "Supercuts"] },
  { keywords: ["bank", "atm"], suggestions: ["Bank", "Chase Bank", "Bank of America", "Wells Fargo", "ATM"] },
  { keywords: ["gas", "fuel", "station"], suggestions: ["Gas Station", "Shell", "Chevron", "76", "Costco Gas"] },
  { keywords: ["pharmacy", "drug"], suggestions: ["CVS", "Walgreens", "Rite Aid", "Pharmacy"] },
  { keywords: ["grocery", "supermarket", "market"], suggestions: ["Grocery Store", "Whole Foods", "Trader Joe's", "Safeway", "Kroger"] },
  { keywords: ["costco", "warehouse"], suggestions: ["Costco", "Sam's Club", "BJ's"] },
  { keywords: ["apple", "tech"], suggestions: ["Apple Store", "Best Buy", "Tech Store"] },
  { keywords: ["home", "house"], suggestions: ["My Place", "Home", "My House", "Apartment"] },
  { keywords: ["work", "office"], suggestions: ["Work", "Office", "Workplace"] },
];

// Generate smart suggestions based on query
function getSmartSuggestions(query: string): { id: string; name: string; address: string; fullAddress: string }[] {
  const queryLower = query.toLowerCase().trim();
  const suggestions: { id: string; name: string; address: string; fullAddress: string }[] = [];

  // First, always add the user's exact input as an option
  suggestions.push({
    id: `custom-${Date.now()}`,
    name: query,
    address: "Use as custom location",
    fullAddress: query,
  });

  // Find matching categories
  for (const category of PLACE_CATEGORIES) {
    const matches = category.keywords.some(keyword =>
      queryLower.includes(keyword) || keyword.includes(queryLower)
    );

    if (matches) {
      for (const suggestion of category.suggestions) {
        if (!suggestions.find(s => s.name.toLowerCase() === suggestion.toLowerCase())) {
          suggestions.push({
            id: `smart-${suggestion.replace(/\s+/g, '-').toLowerCase()}-${Date.now()}`,
            name: suggestion,
            address: "Search nearby",
            fullAddress: suggestion,
          });
        }
        if (suggestions.length >= 8) break;
      }
    }
    if (suggestions.length >= 8) break;
  }

  // If we still don't have enough suggestions, add generic place types
  if (suggestions.length < 4) {
    const genericTypes = [
      { name: `${query} near me`, address: "Search nearby" },
      { name: `${query} restaurant`, address: "Search restaurants" },
      { name: `${query} downtown`, address: "Search downtown area" },
    ];

    for (const type of genericTypes) {
      if (!suggestions.find(s => s.name.toLowerCase() === type.name.toLowerCase())) {
        suggestions.push({
          id: `generic-${Date.now()}-${suggestions.length}`,
          name: type.name,
          address: type.address,
          fullAddress: type.name,
        });
      }
      if (suggestions.length >= 8) break;
    }
  }

  return suggestions.slice(0, 8);
}

// GET /api/places/search?query=... - Search for places
placesRouter.get("/search", async (c) => {
  const query = c.req.query("query");

  if (!query || query.length < 2) {
    return c.json({ places: [] });
  }

  // If we have a Google API key, use Places Autocomplete API
  if (GOOGLE_API_KEY) {
    try {
      // Use Google Places Autocomplete API for better suggestions
      const response = await fetch(
        `https://maps.googleapis.com/maps/api/place/autocomplete/json?input=${encodeURIComponent(
          query
        )}&types=establishment|geocode&key=${GOOGLE_API_KEY}`
      );

      const data = await response.json();
      console.log("Google Places Autocomplete response:", data.status);

      if (data.status === "OK" && data.predictions && data.predictions.length > 0) {
        const places = data.predictions.slice(0, 8).map((prediction: {
          place_id: string;
          structured_formatting: {
            main_text: string;
            secondary_text?: string;
          };
          description: string;
        }) => ({
          id: prediction.place_id,
          name: prediction.structured_formatting.main_text,
          address: prediction.structured_formatting.secondary_text || prediction.description,
          fullAddress: prediction.description,
        }));

        return c.json({ places });
      }

      // If Autocomplete returns no results, try Text Search as fallback
      if (data.status === "ZERO_RESULTS" || (data.predictions && data.predictions.length === 0)) {
        const textSearchResponse = await fetch(
          `https://maps.googleapis.com/maps/api/place/textsearch/json?query=${encodeURIComponent(
            query
          )}&key=${GOOGLE_API_KEY}`
        );

        const textData = await textSearchResponse.json();

        if (textData.status === "OK" && textData.results && textData.results.length > 0) {
          const places = textData.results.slice(0, 8).map((place: {
            place_id: string;
            name: string;
            formatted_address: string;
          }) => ({
            id: place.place_id,
            name: place.name,
            address: place.formatted_address,
            fullAddress: `${place.name}, ${place.formatted_address}`,
          }));

          return c.json({ places });
        }
      }

      // Fall through to smart suggestions if API didn't return results
      console.log("Google API returned no results, using smart suggestions");
    } catch (error) {
      console.error("Google Places API error:", error);
      // Fall through to smart suggestions
    }
  }

  // Use smart suggestions as fallback (no API key or API error)
  const smartSuggestions = getSmartSuggestions(query);
  return c.json({ places: smartSuggestions });
});
