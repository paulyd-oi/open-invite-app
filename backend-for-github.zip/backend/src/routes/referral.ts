import { Hono } from "hono";
import { db } from "../db";
import { type AppType } from "../types";

export const referralRouter = new Hono<AppType>();

// Reward tiers configuration
const REWARD_TIERS = {
  WEEK_PREMIUM: { count: 1, type: "week_premium", duration: 7 },      // 1 referral = 1 week free
  MONTH_PREMIUM: { count: 5, type: "month_premium", duration: 30 },   // 5 referrals = 1 month free
  YEAR_PREMIUM: { count: 10, type: "year_premium", duration: 365 },   // 10 referrals = 1 year free
  LIFETIME_PREMIUM: { count: 20, type: "lifetime_premium", duration: null }, // 20 referrals = lifetime
};

// Generate a unique referral code from user's name
function generateReferralCode(name: string, id: string): string {
  const cleanName = name
    .replace(/[^a-zA-Z]/g, "")
    .toUpperCase()
    .slice(0, 6);
  const suffix = id.slice(-4).toUpperCase();
  return `${cleanName || "INVITE"}${suffix}`;
}

// GET /api/referral/stats - Get user's referral stats
referralRouter.get("/stats", async (c) => {
  const user = c.get("user");
  if (!user) {
    return c.json({ error: "Unauthorized" }, 401);
  }

  // Get or create referral code
  let dbUser = await db.user.findUnique({
    where: { id: user.id },
    select: { referralCode: true, name: true },
  });

  if (!dbUser) {
    return c.json({ error: "User not found" }, 404);
  }

  let referralCode = dbUser.referralCode;
  if (!referralCode) {
    referralCode = generateReferralCode(dbUser.name || "USER", user.id);
    await db.user.update({
      where: { id: user.id },
      data: { referralCode },
    });
  }

  // Count successful referrals
  const successfulReferrals = await db.referral.count({
    where: {
      referrerId: user.id,
      status: { in: ["signed_up", "rewarded"] },
    },
  });

  // Get pending referrals (invites sent but not yet signed up)
  const pendingReferrals = await db.referral.count({
    where: {
      referrerId: user.id,
      status: "pending",
    },
  });

  // Get earned rewards
  const rewards = await db.referralReward.findMany({
    where: { userId: user.id },
    orderBy: { claimedAt: "desc" },
  });

  // Calculate next reward tier
  let nextReward = null;
  if (successfulReferrals < REWARD_TIERS.WEEK_PREMIUM.count) {
    nextReward = { ...REWARD_TIERS.WEEK_PREMIUM, remaining: REWARD_TIERS.WEEK_PREMIUM.count - successfulReferrals };
  } else if (successfulReferrals < REWARD_TIERS.MONTH_PREMIUM.count) {
    nextReward = { ...REWARD_TIERS.MONTH_PREMIUM, remaining: REWARD_TIERS.MONTH_PREMIUM.count - successfulReferrals };
  } else if (successfulReferrals < REWARD_TIERS.YEAR_PREMIUM.count) {
    nextReward = { ...REWARD_TIERS.YEAR_PREMIUM, remaining: REWARD_TIERS.YEAR_PREMIUM.count - successfulReferrals };
  } else if (successfulReferrals < REWARD_TIERS.LIFETIME_PREMIUM.count) {
    nextReward = { ...REWARD_TIERS.LIFETIME_PREMIUM, remaining: REWARD_TIERS.LIFETIME_PREMIUM.count - successfulReferrals };
  }

  // Generate shareable link - App Store link (update when app is released)
  const shareLink = `https://apps.apple.com/app/open-invite/id123456789`;

  return c.json({
    referralCode,
    shareLink,
    successfulReferrals,
    pendingReferrals,
    totalInvites: successfulReferrals + pendingReferrals,
    rewards,
    nextReward,
    rewardTiers: REWARD_TIERS,
  });
});

// GET /api/referral/code - Get or generate referral code
referralRouter.get("/code", async (c) => {
  const user = c.get("user");
  if (!user) {
    return c.json({ error: "Unauthorized" }, 401);
  }

  const dbUser = await db.user.findUnique({
    where: { id: user.id },
    select: { referralCode: true, name: true },
  });

  if (!dbUser) {
    return c.json({ error: "User not found" }, 404);
  }

  let referralCode = dbUser.referralCode;
  if (!referralCode) {
    referralCode = generateReferralCode(dbUser.name || "USER", user.id);
    await db.user.update({
      where: { id: user.id },
      data: { referralCode },
    });
  }

  // App Store link (update when app is released)
  return c.json({
    referralCode,
    shareLink: `https://apps.apple.com/app/open-invite/id123456789`,
  });
});

// POST /api/referral/track - Track a referral invite (when user shares)
referralRouter.post("/track", async (c) => {
  const user = c.get("user");
  if (!user) {
    return c.json({ error: "Unauthorized" }, 401);
  }

  const body = await c.req.json();
  const { email, phone } = body;

  if (!email && !phone) {
    return c.json({ error: "Email or phone required" }, 400);
  }

  // Check if already referred
  const existing = await db.referral.findFirst({
    where: {
      referrerId: user.id,
      OR: [
        email ? { referredEmail: email.toLowerCase() } : {},
        phone ? { referredPhone: phone } : {},
      ].filter((o) => Object.keys(o).length > 0),
    },
  });

  if (existing) {
    return c.json({ message: "Already invited", referral: existing });
  }

  const referral = await db.referral.create({
    data: {
      referrerId: user.id,
      referredEmail: email?.toLowerCase(),
      referredPhone: phone,
      status: "pending",
    },
  });

  return c.json({ success: true, referral });
});

// POST /api/referral/apply - Apply a referral code (called during sign up)
referralRouter.post("/apply", async (c) => {
  const user = c.get("user");
  if (!user) {
    return c.json({ error: "Unauthorized" }, 401);
  }

  const body = await c.req.json();
  const { referralCode } = body;

  if (!referralCode) {
    return c.json({ error: "Referral code required" }, 400);
  }

  // Find the referrer by code
  const referrer = await db.user.findUnique({
    where: { referralCode: referralCode.toUpperCase() },
    select: { id: true, name: true },
  });

  if (!referrer) {
    return c.json({ error: "Invalid referral code" }, 404);
  }

  if (referrer.id === user.id) {
    return c.json({ error: "Cannot use your own referral code" }, 400);
  }

  // Check if user was already referred
  const dbUser = await db.user.findUnique({
    where: { id: user.id },
    select: { referredBy: true, email: true, phone: true },
  });

  if (dbUser?.referredBy) {
    return c.json({ error: "Already used a referral code" }, 400);
  }

  // Update user with referrer info
  await db.user.update({
    where: { id: user.id },
    data: { referredBy: referrer.id },
  });

  // Create or update referral record
  const existingReferral = await db.referral.findFirst({
    where: {
      referrerId: referrer.id,
      OR: [
        dbUser?.email ? { referredEmail: dbUser.email.toLowerCase() } : {},
        dbUser?.phone ? { referredPhone: dbUser.phone } : {},
      ].filter((o) => Object.keys(o).length > 0),
    },
  });

  if (existingReferral) {
    await db.referral.update({
      where: { id: existingReferral.id },
      data: {
        referredUserId: user.id,
        status: "signed_up",
      },
    });
  } else {
    await db.referral.create({
      data: {
        referrerId: referrer.id,
        referredUserId: user.id,
        referredEmail: dbUser?.email?.toLowerCase(),
        status: "signed_up",
      },
    });
  }

  // Check if referrer earned a new reward
  const successfulCount = await db.referral.count({
    where: {
      referrerId: referrer.id,
      status: { in: ["signed_up", "rewarded"] },
    },
  });

  // Check reward milestones
  let newReward = null;
  for (const tier of Object.values(REWARD_TIERS)) {
    if (successfulCount === tier.count) {
      // Check if this reward was already given
      const existingReward = await db.referralReward.findFirst({
        where: {
          userId: referrer.id,
          rewardType: tier.type,
        },
      });

      if (!existingReward) {
        const expiresAt = tier.duration
          ? new Date(Date.now() + tier.duration * 24 * 60 * 60 * 1000)
          : null;

        newReward = await db.referralReward.create({
          data: {
            userId: referrer.id,
            rewardType: tier.type,
            referralCount: successfulCount,
            expiresAt,
          },
        });

        // TODO: Send push notification to referrer about their reward
        console.log(`🎉 User ${referrer.id} earned ${tier.type} for ${successfulCount} referrals!`);
      }
    }
  }

  // Give the new user a welcome bonus (1 week premium trial)
  const existingWelcomeReward = await db.referralReward.findFirst({
    where: {
      userId: user.id,
      rewardType: "welcome_week",
    },
  });

  if (!existingWelcomeReward) {
    await db.referralReward.create({
      data: {
        userId: user.id,
        rewardType: "welcome_week",
        referralCount: 0,
        expiresAt: new Date(Date.now() + 7 * 24 * 60 * 60 * 1000),
      },
    });
  }

  return c.json({
    success: true,
    referrerName: referrer.name,
    welcomeBonus: "1 week premium trial",
  });
});

// GET /api/referral/leaderboard - Get top referrers
referralRouter.get("/leaderboard", async (c) => {
  const user = c.get("user");
  if (!user) {
    return c.json({ error: "Unauthorized" }, 401);
  }

  // Get top 10 referrers
  const topReferrers = await db.referral.groupBy({
    by: ["referrerId"],
    where: { status: { in: ["signed_up", "rewarded"] } },
    _count: { referrerId: true },
    orderBy: { _count: { referrerId: "desc" } },
    take: 10,
  });

  // Get user details for top referrers
  const leaderboard = await Promise.all(
    topReferrers.map(async (r, index) => {
      const referrer = await db.user.findUnique({
        where: { id: r.referrerId },
        select: { name: true, image: true },
      });
      return {
        rank: index + 1,
        name: referrer?.name || "Anonymous",
        image: referrer?.image,
        count: r._count.referrerId,
        isCurrentUser: r.referrerId === user.id,
      };
    })
  );

  // Get current user's rank if not in top 10
  const userStats = await db.referral.count({
    where: {
      referrerId: user.id,
      status: { in: ["signed_up", "rewarded"] },
    },
  });

  return c.json({
    leaderboard,
    userStats: {
      count: userStats,
      inTop10: leaderboard.some((l) => l.isCurrentUser),
    },
  });
});

// GET /api/referral/validate/:code - Validate a referral code (public)
referralRouter.get("/validate/:code", async (c) => {
  const code = c.req.param("code");

  const referrer = await db.user.findUnique({
    where: { referralCode: code.toUpperCase() },
    select: { name: true, image: true },
  });

  if (!referrer) {
    return c.json({ valid: false }, 404);
  }

  return c.json({
    valid: true,
    referrerName: referrer.name,
    referrerImage: referrer.image,
  });
});
