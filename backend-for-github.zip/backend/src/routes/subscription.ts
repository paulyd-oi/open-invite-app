import { Hono } from "hono";
import { db } from "../db";
import { type AppType } from "../types";

export const subscriptionRouter = new Hono<AppType>();

// Beta mode - set to true to give everyone all features for free
const BETA_MODE = true;

// Free tier limits
const FREE_TIER_LIMITS = {
  maxFriends: 10,
  features: {
    unlimitedFriends: false,
    friendGroups: false,
    whosFree: false,
    workSchedule: false,
    friendNotes: false,
  },
};

const PREMIUM_FEATURES = {
  maxFriends: Infinity,
  features: {
    unlimitedFriends: true,
    friendGroups: true,
    whosFree: true,
    workSchedule: true,
    friendNotes: true,
  },
};

// GET /api/subscription - Get current user's subscription status
subscriptionRouter.get("/", async (c) => {
  const user = c.get("user");
  if (!user) {
    return c.json({ error: "Unauthorized" }, 401);
  }

  let subscription = await db.subscription.findUnique({
    where: { userId: user.id },
  });

  // Create default free subscription if none exists
  if (!subscription) {
    subscription = await db.subscription.create({
      data: {
        userId: user.id,
        tier: "free",
      },
    });
  }

  // Check if premium has expired
  const isPremiumActive =
    subscription.tier === "premium" &&
    subscription.expiresAt &&
    new Date(subscription.expiresAt) > new Date();

  // In beta mode, everyone gets premium features
  const effectiveTier = BETA_MODE ? "premium" : (isPremiumActive ? "premium" : "free");
  const limits = BETA_MODE ? PREMIUM_FEATURES : (effectiveTier === "premium" ? PREMIUM_FEATURES : FREE_TIER_LIMITS);

  // Get current friend count
  const friendCount = await db.friendship.count({
    where: { userId: user.id },
  });

  return c.json({
    subscription: {
      tier: effectiveTier,
      expiresAt: isPremiumActive ? subscription.expiresAt?.toISOString() : null,
      purchasedAt: subscription.purchasedAt?.toISOString() ?? null,
      isBeta: BETA_MODE,
    },
    limits: {
      maxFriends: limits.maxFriends === Infinity ? null : limits.maxFriends,
      currentFriends: friendCount,
      canAddMoreFriends: BETA_MODE || effectiveTier === "premium" || friendCount < FREE_TIER_LIMITS.maxFriends,
      friendsRemaining: BETA_MODE || effectiveTier === "premium" ? null : Math.max(0, FREE_TIER_LIMITS.maxFriends - friendCount),
    },
    features: limits.features,
  });
});

// POST /api/subscription/upgrade - Upgrade to premium (placeholder for RevenueCat integration)
subscriptionRouter.post("/upgrade", async (c) => {
  const user = c.get("user");
  if (!user) {
    return c.json({ error: "Unauthorized" }, 401);
  }

  const body = await c.req.json();
  const { transactionId, plan } = body; // plan: "yearly" or "monthly"

  // Calculate expiration based on plan
  const now = new Date();
  const expiresAt = new Date(now);
  if (plan === "yearly") {
    expiresAt.setFullYear(expiresAt.getFullYear() + 1);
  } else {
    expiresAt.setMonth(expiresAt.getMonth() + 1);
  }

  const subscription = await db.subscription.upsert({
    where: { userId: user.id },
    create: {
      userId: user.id,
      tier: "premium",
      expiresAt,
      purchasedAt: now,
      transactionId,
    },
    update: {
      tier: "premium",
      expiresAt,
      purchasedAt: now,
      transactionId,
    },
  });

  return c.json({
    success: true,
    subscription: {
      tier: subscription.tier,
      expiresAt: subscription.expiresAt?.toISOString(),
      purchasedAt: subscription.purchasedAt?.toISOString(),
    },
  });
});

// POST /api/subscription/restore - Restore purchases
subscriptionRouter.post("/restore", async (c) => {
  const user = c.get("user");
  if (!user) {
    return c.json({ error: "Unauthorized" }, 401);
  }

  // This would integrate with RevenueCat to restore purchases
  // For now, just return current subscription status
  const subscription = await db.subscription.findUnique({
    where: { userId: user.id },
  });

  if (!subscription || subscription.tier !== "premium") {
    return c.json({
      success: false,
      message: "No active subscription found",
    });
  }

  return c.json({
    success: true,
    subscription: {
      tier: subscription.tier,
      expiresAt: subscription.expiresAt?.toISOString(),
    },
  });
});

// GET /api/subscription/check-feature/:feature - Check if user can use a feature
subscriptionRouter.get("/check-feature/:feature", async (c) => {
  const user = c.get("user");
  if (!user) {
    return c.json({ error: "Unauthorized" }, 401);
  }

  const feature = c.req.param("feature") as keyof typeof PREMIUM_FEATURES.features;

  // In beta mode, everyone has access to all features
  if (BETA_MODE) {
    return c.json({
      feature,
      hasAccess: true,
      requiresPremium: PREMIUM_FEATURES.features[feature] ?? false,
      isBeta: true,
    });
  }

  const subscription = await db.subscription.findUnique({
    where: { userId: user.id },
  });

  const isPremiumActive =
    subscription?.tier === "premium" &&
    subscription.expiresAt &&
    new Date(subscription.expiresAt) > new Date();

  const hasAccess = isPremiumActive || !PREMIUM_FEATURES.features[feature];

  return c.json({
    feature,
    hasAccess,
    requiresPremium: PREMIUM_FEATURES.features[feature] ?? false,
    isBeta: false,
  });
});
