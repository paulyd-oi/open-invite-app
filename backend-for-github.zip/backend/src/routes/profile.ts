import { Hono } from "hono";
import { db } from "../db";
import { type AppType } from "../types";
import { updateProfileRequestSchema, searchUsersRequestSchema } from "@/shared/contracts";
import { getBlockedUserIds, getBlockedByUserIds } from "./blocked";

export const profileRouter = new Hono<AppType>();

// GET /api/profile - Get current user's profile
profileRouter.get("/", async (c) => {
  const user = c.get("user");
  if (!user) {
    return c.json({ error: "Unauthorized" }, 401);
  }

  const profile = await db.profile.findUnique({
    where: { userId: user.id },
  });

  const userData = await db.user.findUnique({
    where: { id: user.id },
    select: {
      id: true,
      name: true,
      email: true,
      phone: true,
      image: true,
      Profile: true,
    },
  });

  return c.json({
    profile,
    user: userData,
  });
});

// PUT /api/profile - Update current user's profile
profileRouter.put("/", async (c) => {
  const user = c.get("user");
  if (!user) {
    return c.json({ error: "Unauthorized" }, 401);
  }

  const body = await c.req.json();
  const parsed = updateProfileRequestSchema.safeParse(body);

  if (!parsed.success) {
    return c.json({ error: "Invalid request", details: parsed.error }, 400);
  }

  const { handle, bio, calendarBio, avatarUrl, name, phone, birthday, showBirthdayToFriends, hideBirthdays, omitBirthdayYear } = parsed.data;

  // Update user name, image, and/or phone if provided
  const userUpdates: { name?: string; image?: string; phone?: string | null } = {};
  if (name) {
    userUpdates.name = name;
  }
  if (avatarUrl) {
    userUpdates.image = avatarUrl;
  }
  if (phone !== undefined) {
    // Normalize phone number - remove non-digits except +
    const normalizedPhone = phone ? phone.replace(/[^\d+]/g, '') : null;
    userUpdates.phone = normalizedPhone;
  }

  if (Object.keys(userUpdates).length > 0) {
    await db.user.update({
      where: { id: user.id },
      data: userUpdates,
    });
  }

  // Update or create profile
  let profile = null;
  const hasBirthdayUpdates = birthday !== undefined || showBirthdayToFriends !== undefined || hideBirthdays !== undefined || omitBirthdayYear !== undefined;
  if (handle || bio !== undefined || calendarBio !== undefined || avatarUrl !== undefined || hasBirthdayUpdates) {
    const existingProfile = await db.profile.findUnique({
      where: { userId: user.id },
    });

    if (existingProfile) {
      profile = await db.profile.update({
        where: { userId: user.id },
        data: {
          handle: handle ?? existingProfile.handle,
          bio: bio ?? existingProfile.bio,
          calendarBio: calendarBio ?? existingProfile.calendarBio,
          avatarUrl: avatarUrl ?? existingProfile.avatarUrl,
          birthday: birthday ? new Date(birthday) : (birthday === null ? null : existingProfile.birthday),
          showBirthdayToFriends: showBirthdayToFriends ?? existingProfile.showBirthdayToFriends,
          hideBirthdays: hideBirthdays ?? existingProfile.hideBirthdays,
          omitBirthdayYear: omitBirthdayYear ?? existingProfile.omitBirthdayYear,
        },
      });
    } else if (handle) {
      // Check if handle is taken
      const handleTaken = await db.profile.findUnique({
        where: { handle },
      });

      if (handleTaken) {
        return c.json({ error: "Handle already taken" }, 400);
      }

      profile = await db.profile.create({
        data: {
          userId: user.id,
          handle,
          bio: bio ?? null,
          calendarBio: calendarBio ?? null,
          avatarUrl: avatarUrl ?? null,
          birthday: birthday ? new Date(birthday) : null,
          showBirthdayToFriends: showBirthdayToFriends ?? false,
          hideBirthdays: hideBirthdays ?? false,
          omitBirthdayYear: omitBirthdayYear ?? false,
        },
      });
    } else {
      // Create profile without handle if we just have avatarUrl or bio
      profile = await db.profile.create({
        data: {
          userId: user.id,
          handle: `user_${user.id.slice(0, 8)}`,
          bio: bio ?? null,
          calendarBio: calendarBio ?? null,
          avatarUrl: avatarUrl ?? null,
          birthday: birthday ? new Date(birthday) : null,
          showBirthdayToFriends: showBirthdayToFriends ?? false,
          hideBirthdays: hideBirthdays ?? false,
          omitBirthdayYear: omitBirthdayYear ?? false,
        },
      });
    }
  }

  // Format birthday for response
  const formattedProfile = profile ? {
    ...profile,
    birthday: profile.birthday ? profile.birthday.toISOString() : null,
  } : null;

  return c.json({ success: true, profile: formattedProfile });
});

// POST /api/users/search - Search users by email or handle
profileRouter.post("/search", async (c) => {
  const user = c.get("user");
  if (!user) {
    return c.json({ error: "Unauthorized" }, 401);
  }

  const body = await c.req.json();
  const parsed = searchUsersRequestSchema.safeParse(body);

  if (!parsed.success) {
    return c.json({ error: "Invalid request", details: parsed.error }, 400);
  }

  const query = parsed.data.query.toLowerCase();
  // Normalize for phone search - remove non-digits
  const normalizedQuery = query.replace(/[^\d]/g, '');

  // Get blocked user IDs (both directions - exclude those I blocked AND those who blocked me)
  const [blockedByMe, blockedMe] = await Promise.all([
    getBlockedUserIds(user.id),
    getBlockedByUserIds(user.id),
  ]);
  const allBlockedIds = [...new Set([...blockedByMe, ...blockedMe])];

  const users = await db.user.findMany({
    where: {
      AND: [
        { id: { not: user.id } }, // Exclude current user
        { id: { notIn: allBlockedIds } }, // Exclude blocked users (both directions)
        {
          OR: [
            { email: { contains: query } },
            { name: { contains: query } },
            { Profile: { handle: { contains: query } } },
            // Search by phone if query looks like a phone number (has 4+ digits)
            ...(normalizedQuery.length >= 4 ? [{ phone: { contains: normalizedQuery } }] : []),
          ],
        },
      ],
    },
    select: {
      id: true,
      name: true,
      email: true,
      image: true,
      Profile: true,
    },
    take: 20,
  });

  return c.json({ users });
});

// GET /api/profile/stats - Get user's profile stats for gamification
profileRouter.get("/stats", async (c) => {
  const user = c.get("user");
  if (!user) {
    return c.json({ error: "Unauthorized" }, 401);
  }

  // Get all events hosted by user
  const hostedEvents = await db.event.findMany({
    where: { userId: user.id },
    select: {
      id: true,
      category: true,
      startTime: true,
      joinRequests: {
        where: { status: "accepted" },
        select: { userId: true },
      },
    },
    orderBy: { startTime: "desc" },
  });

  // Get events user has attended (accepted join requests)
  const attendedEvents = await db.eventJoinRequest.findMany({
    where: {
      userId: user.id,
      status: "accepted",
    },
    include: {
      event: {
        select: {
          id: true,
          userId: true,
          startTime: true,
        },
      },
    },
  });

  // Calculate hosted events count
  const hostedCount = hostedEvents.length;

  // Calculate attended events count
  const attendedCount = attendedEvents.length;

  // Calculate event types breakdown
  const categoryBreakdown: Record<string, number> = {};
  for (const event of hostedEvents) {
    const cat = event.category ?? "other";
    categoryBreakdown[cat] = (categoryBreakdown[cat] ?? 0) + 1;
  }

  // Find max attendees for any single event
  let maxAttendeesEvent = 0;
  for (const event of hostedEvents) {
    const attendees = event.joinRequests.length;
    if (attendees > maxAttendeesEvent) {
      maxAttendeesEvent = attendees;
    }
  }

  // Calculate hosting streak (consecutive weeks with at least one hosted event)
  const now = new Date();
  let currentStreak = 0;
  const weekMs = 7 * 24 * 60 * 60 * 1000;

  // Sort events by date (most recent first) and check consecutive weeks
  const sortedEvents = [...hostedEvents].sort(
    (a, b) => new Date(b.startTime).getTime() - new Date(a.startTime).getTime()
  );

  if (sortedEvents.length > 0) {
    let checkWeekStart = new Date(now);
    checkWeekStart.setDate(checkWeekStart.getDate() - checkWeekStart.getDay()); // Start of current week
    checkWeekStart.setHours(0, 0, 0, 0);

    // Check each week going back
    while (true) {
      const weekEnd = new Date(checkWeekStart.getTime() + weekMs);
      const hasEventThisWeek = sortedEvents.some((e) => {
        const eventTime = new Date(e.startTime);
        return eventTime >= checkWeekStart && eventTime < weekEnd;
      });

      if (hasEventThisWeek) {
        currentStreak++;
        checkWeekStart = new Date(checkWeekStart.getTime() - weekMs);
      } else {
        break;
      }
    }
  }

  // Calculate top 3 friends (friends we've attended most events together with)
  // This includes: events I hosted they attended + events they hosted I attended
  const friendEventCounts: Record<string, { count: number; friendId: string }> = {};

  // Count friends who attended my events
  for (const event of hostedEvents) {
    for (const joinRequest of event.joinRequests) {
      const friendId = joinRequest.userId;
      if (!friendEventCounts[friendId]) {
        friendEventCounts[friendId] = { count: 0, friendId };
      }
      friendEventCounts[friendId].count++;
    }
  }

  // Count events I attended that were hosted by friends
  for (const attended of attendedEvents) {
    const hostId = attended.event.userId;
    if (!friendEventCounts[hostId]) {
      friendEventCounts[hostId] = { count: 0, friendId: hostId };
    }
    friendEventCounts[hostId].count++;
  }

  // Get top 3 friend IDs by event count
  const topFriendIds = Object.values(friendEventCounts)
    .sort((a, b) => b.count - a.count)
    .slice(0, 3);

  // Fetch friend details
  const topFriends = await Promise.all(
    topFriendIds.map(async ({ friendId, count }) => {
      const friend = await db.user.findUnique({
        where: { id: friendId },
        select: {
          id: true,
          name: true,
          image: true,
        },
      });
      return friend ? { ...friend, eventsCount: count } : null;
    })
  );

  // Define achievements
  const achievements = [
    {
      id: "first_host",
      name: "Party Starter",
      description: "Host your first event",
      emoji: "🎉",
      unlocked: hostedCount >= 1,
      progress: Math.min(hostedCount, 1),
      target: 1,
    },
    {
      id: "host_10",
      name: "Social Butterfly",
      description: "Host 10 events",
      emoji: "🦋",
      unlocked: hostedCount >= 10,
      progress: Math.min(hostedCount, 10),
      target: 10,
    },
    {
      id: "host_20",
      name: "Event Master",
      description: "Host 20 events",
      emoji: "👑",
      unlocked: hostedCount >= 20,
      progress: Math.min(hostedCount, 20),
      target: 20,
    },
    {
      id: "attend_10",
      name: "Good Friend",
      description: "Attend 10 events",
      emoji: "🤝",
      unlocked: attendedCount >= 10,
      progress: Math.min(attendedCount, 10),
      target: 10,
    },
    {
      id: "attend_30",
      name: "Social Star",
      description: "Attend 30 events",
      emoji: "⭐",
      unlocked: attendedCount >= 30,
      progress: Math.min(attendedCount, 30),
      target: 30,
    },
    {
      id: "big_event",
      name: "Big Bash",
      description: "Host an event with 10+ attendees",
      emoji: "🎊",
      unlocked: maxAttendeesEvent >= 10,
      progress: Math.min(maxAttendeesEvent, 10),
      target: 10,
    },
    {
      id: "mega_event",
      name: "Mega Party",
      description: "Host an event with 50+ attendees",
      emoji: "🔥",
      unlocked: maxAttendeesEvent >= 50,
      progress: Math.min(maxAttendeesEvent, 50),
      target: 50,
    },
    {
      id: "century_event",
      name: "Legendary Host",
      description: "Host an event with 100+ attendees",
      emoji: "💯",
      unlocked: maxAttendeesEvent >= 100,
      progress: Math.min(maxAttendeesEvent, 100),
      target: 100,
    },
    {
      id: "streak_4",
      name: "Consistent",
      description: "4 week hosting streak",
      emoji: "🔄",
      unlocked: currentStreak >= 4,
      progress: Math.min(currentStreak, 4),
      target: 4,
    },
    {
      id: "streak_12",
      name: "Dedicated Host",
      description: "12 week hosting streak",
      emoji: "💪",
      unlocked: currentStreak >= 12,
      progress: Math.min(currentStreak, 12),
      target: 12,
    },
  ];

  return c.json({
    stats: {
      hostedCount,
      attendedCount,
      categoryBreakdown,
      currentStreak,
      maxAttendeesEvent,
    },
    topFriends: topFriends.filter(Boolean),
    achievements,
  });
});

// GET /api/users/:id/profile - Get a user's public profile (for viewing non-friends)
profileRouter.get("/:id/profile", async (c) => {
  const currentUser = c.get("user");
  if (!currentUser) {
    return c.json({ error: "Unauthorized" }, 401);
  }

  const userId = c.req.param("id");

  // Get blocked user IDs (both directions)
  const [blockedByMe, blockedMe] = await Promise.all([
    getBlockedUserIds(currentUser.id),
    getBlockedByUserIds(currentUser.id),
  ]);
  const allBlockedIds = [...new Set([...blockedByMe, ...blockedMe])];

  // Check if user is blocked
  if (allBlockedIds.includes(userId)) {
    return c.json({ error: "User not found" }, 404);
  }

  // Fetch the user
  const user = await db.user.findUnique({
    where: { id: userId },
    select: {
      id: true,
      name: true,
      email: true,
      image: true,
      Profile: {
        select: {
          handle: true,
          bio: true,
          calendarBio: true,
          avatarUrl: true,
        },
      },
    },
  });

  if (!user) {
    return c.json({ error: "User not found" }, 404);
  }

  // Check if they are already friends
  const friendship = await db.friendship.findUnique({
    where: {
      userId_friendId: {
        userId: currentUser.id,
        friendId: userId,
      },
    },
  });

  const isFriend = !!friendship;

  // Check if there's a pending friend request (either direction)
  const pendingRequest = await db.friendRequest.findFirst({
    where: {
      OR: [
        { senderId: currentUser.id, receiverId: userId, status: "pending" },
        { senderId: userId, receiverId: currentUser.id, status: "pending" },
      ],
    },
  });

  const hasPendingRequest = !!pendingRequest;
  // Check if this is an incoming request (they sent to me)
  const incomingRequestId = pendingRequest?.senderId === userId ? pendingRequest.id : null;

  return c.json({
    user: {
      ...user,
      // Hide email for privacy if not friends
      email: isFriend ? user.email : user.email.split("@")[0].slice(0, 3) + "***@***",
    },
    isFriend,
    hasPendingRequest,
    incomingRequestId, // ID of the request if they sent it to me (so I can accept/reject)
  });
});
