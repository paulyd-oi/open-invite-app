import { Hono } from "hono";
import { db } from "../db";
import { type AppType } from "../types";
import {
  createEventRequestSchema,
  updateEventRequestSchema,
  joinEventRequestSchema,
  updateJoinRequestSchema,
  createCommentRequestSchema,
} from "@/shared/contracts";
import { getBlockedUserIds, getBlockedByUserIds } from "./blocked";

export const eventsRouter = new Hono<AppType>();

// Helper to serialize dates in event objects
const serializeEvent = (event: {
  id: string;
  title: string;
  description: string | null;
  location: string | null;
  emoji: string;
  startTime: Date;
  endTime: Date | null;
  isRecurring: boolean;
  recurrence: string | null;
  visibility: string;
  userId: string;
  createdAt: Date;
  updatedAt: Date;
  user?: { id: string; name: string | null; email: string; image: string | null } | null;
  groupVisibility?: Array<{
    groupId: string;
    group: { id: string; name: string; color: string };
  }>;
  joinRequests?: Array<{
    id: string;
    userId: string;
    status: string;
    message: string | null;
    user: { id: string; name: string | null; image: string | null };
  }>;
}) => ({
  ...event,
  startTime: event.startTime.toISOString(),
  endTime: event.endTime?.toISOString() ?? null,
  createdAt: event.createdAt.toISOString(),
  updatedAt: event.updatedAt.toISOString(),
});

// GET /api/events - Get user's own events
eventsRouter.get("/", async (c) => {
  const user = c.get("user");
  if (!user) {
    return c.json({ error: "Unauthorized" }, 401);
  }

  const events = await db.event.findMany({
    where: { userId: user.id },
    include: {
      groupVisibility: {
        include: {
          group: { select: { id: true, name: true, color: true } },
        },
      },
      joinRequests: {
        include: {
          user: { select: { id: true, name: true, image: true } },
        },
      },
    },
    orderBy: { startTime: "asc" },
  });

  return c.json({ events: events.map(serializeEvent) });
});

// GET /api/events/feed - Get activity feed (friends' open events)
eventsRouter.get("/feed", async (c) => {
  const user = c.get("user");
  if (!user) {
    return c.json({ error: "Unauthorized" }, 401);
  }

  // Get blocked user IDs (both directions)
  const [blockedByMe, blockedMe] = await Promise.all([
    getBlockedUserIds(user.id),
    getBlockedByUserIds(user.id),
  ]);
  const allBlockedIds = [...new Set([...blockedByMe, ...blockedMe])];

  // Get user's friendships (where they are friends, not blocked)
  const friendships = await db.friendship.findMany({
    where: {
      userId: user.id,
      isBlocked: false,
      friendId: { notIn: allBlockedIds }, // Exclude blocked users
    },
    include: {
      groupMemberships: true,
    },
  });

  const friendIds = friendships.map((f) => f.friendId);

  // Get all friend events that are either:
  // 1. visibility = "all_friends" OR
  // 2. visibility = "specific_groups" AND the user is in one of those groups
  const now = new Date();

  const events = await db.event.findMany({
    where: {
      userId: { in: friendIds },
      startTime: { gte: now },
      OR: [
        { visibility: "all_friends" },
        {
          visibility: "specific_groups",
          groupVisibility: {
            some: {
              groupId: {
                in: friendships.flatMap((f) =>
                  f.groupMemberships.map((m) => m.groupId)
                ),
              },
            },
          },
        },
      ],
    },
    include: {
      user: { select: { id: true, name: true, email: true, image: true } },
      groupVisibility: {
        include: {
          group: { select: { id: true, name: true, color: true } },
        },
      },
      joinRequests: {
        where: { userId: user.id },
        include: {
          user: { select: { id: true, name: true, image: true } },
        },
      },
    },
    orderBy: { startTime: "asc" },
  });

  return c.json({ events: events.map(serializeEvent) });
});

// GET /api/events/attending - Get events user is attending (joined friend events)
eventsRouter.get("/attending", async (c) => {
  const user = c.get("user");
  if (!user) {
    return c.json({ error: "Unauthorized" }, 401);
  }

  // Get all events where user has an accepted join request
  const joinRequests = await db.eventJoinRequest.findMany({
    where: {
      userId: user.id,
      status: "accepted",
    },
    include: {
      event: {
        include: {
          user: { select: { id: true, name: true, email: true, image: true } },
          groupVisibility: {
            include: {
              group: { select: { id: true, name: true, color: true } },
            },
          },
          joinRequests: {
            where: { userId: user.id },
            include: {
              user: { select: { id: true, name: true, image: true } },
            },
          },
        },
      },
    },
  });

  const events = joinRequests
    .map((jr) => jr.event)
    .filter((event) => event !== null);

  return c.json({ events: events.map(serializeEvent) });
});

// POST /api/events - Create new event
eventsRouter.post("/", async (c) => {
  const user = c.get("user");
  if (!user) {
    return c.json({ error: "Unauthorized" }, 401);
  }

  const body = await c.req.json();
  const parsed = createEventRequestSchema.safeParse(body);

  if (!parsed.success) {
    return c.json({ error: "Invalid request", details: parsed.error }, 400);
  }

  const { groupIds, sendNotification, ...eventData } = parsed.data;

  const startTime = new Date(eventData.startTime);
  const createdEvents: Array<typeof event> = [];

  // Helper to create a single event
  const createSingleEvent = async (eventStartTime: Date) => {
    return await db.event.create({
      data: {
        ...eventData,
        emoji: eventData.emoji ?? "📅",
        startTime: eventStartTime,
        endTime: eventData.endTime ? new Date(eventData.endTime) : null,
        userId: user.id,
        groupVisibility:
          eventData.visibility === "specific_groups" && groupIds
            ? {
                create: groupIds.map((groupId) => ({ groupId })),
              }
            : undefined,
      },
      include: {
        groupVisibility: {
          include: {
            group: { select: { id: true, name: true, color: true } },
          },
        },
      },
    });
  };

  // Create the first event
  const event = await createSingleEvent(startTime);
  createdEvents.push(event);

  // If weekly recurring, create events for each week of the month (4 weeks total)
  if (eventData.isRecurring && eventData.recurrence === "weekly") {
    const weeksToCreate = 3; // Create 3 more weeks (4 total including the first)

    for (let week = 1; week <= weeksToCreate; week++) {
      const nextWeekDate = new Date(startTime);
      nextWeekDate.setDate(nextWeekDate.getDate() + (week * 7));

      const recurringEvent = await createSingleEvent(nextWeekDate);
      createdEvents.push(recurringEvent);
    }
  }

  // If monthly recurring, create events for the next 2 months (3 total including the first)
  if (eventData.isRecurring && eventData.recurrence === "monthly") {
    const monthsToCreate = 2; // Create 2 more months (3 total)

    for (let month = 1; month <= monthsToCreate; month++) {
      const nextMonthDate = new Date(startTime);
      nextMonthDate.setMonth(nextMonthDate.getMonth() + month);

      const recurringEvent = await createSingleEvent(nextMonthDate);
      createdEvents.push(recurringEvent);
    }
  }

  // Create notifications for friends who can see this event (only for the first event)
  // Only send notifications if sendNotification is true (defaults to true if not specified)
  const shouldNotify = sendNotification !== false;

  if (shouldNotify) {
    const friendships = await db.friendship.findMany({
      where: {
        friendId: user.id, // People who have user as friend
        isBlocked: false,
      },
      include: {
        groupMemberships: true,
      },
    });

    // Filter to friends who can see this event
    const notifyUserIds = friendships
      .filter((f) => {
        if (eventData.visibility === "all_friends") return true;
        if (eventData.visibility === "specific_groups" && groupIds) {
          return f.groupMemberships.some((m) => groupIds.includes(m.groupId));
        }
        return false;
      })
      .map((f) => f.userId);

    // Create notifications
    if (notifyUserIds.length > 0) {
      const notificationBody = eventData.isRecurring && eventData.recurrence === "weekly"
        ? `${user.name ?? user.email} is planning: ${eventData.title} (Weekly)`
        : eventData.isRecurring && eventData.recurrence === "monthly"
        ? `${user.name ?? user.email} is planning: ${eventData.title} (Monthly)`
        : `${user.name ?? user.email} is planning: ${eventData.title}`;

      await db.notification.createMany({
        data: notifyUserIds.map((userId) => ({
          userId,
          type: "new_event",
          title: "New Event",
          body: notificationBody,
          data: JSON.stringify({ eventId: event.id }),
        })),
      });
    }
  }

  return c.json({ event: serializeEvent(event) });
});

// PUT /api/events/:id - Update event
eventsRouter.put("/:id", async (c) => {
  const user = c.get("user");
  if (!user) {
    return c.json({ error: "Unauthorized" }, 401);
  }

  const eventId = c.req.param("id");
  const body = await c.req.json();
  const parsed = updateEventRequestSchema.safeParse(body);

  if (!parsed.success) {
    return c.json({ error: "Invalid request", details: parsed.error }, 400);
  }

  // Check if user owns the event
  const existingEvent = await db.event.findFirst({
    where: { id: eventId, userId: user.id },
  });

  if (!existingEvent) {
    return c.json({ error: "Event not found" }, 404);
  }

  const { groupIds, ...updateData } = parsed.data;

  // Update event and group visibility
  const event = await db.event.update({
    where: { id: eventId },
    data: {
      ...updateData,
      startTime: updateData.startTime
        ? new Date(updateData.startTime)
        : undefined,
      endTime: updateData.endTime ? new Date(updateData.endTime) : undefined,
    },
    include: {
      groupVisibility: {
        include: {
          group: { select: { id: true, name: true, color: true } },
        },
      },
    },
  });

  // Update group visibility if provided
  if (groupIds !== undefined) {
    await db.eventGroupVisibility.deleteMany({ where: { eventId } });
    if (groupIds.length > 0) {
      await db.eventGroupVisibility.createMany({
        data: groupIds.map((groupId) => ({ eventId, groupId })),
      });
    }
  }

  const updatedEvent = await db.event.findUnique({
    where: { id: eventId },
    include: {
      groupVisibility: {
        include: {
          group: { select: { id: true, name: true, color: true } },
        },
      },
    },
  });

  return c.json({ event: serializeEvent(updatedEvent!) });
});

// DELETE /api/events/:id - Delete event
eventsRouter.delete("/:id", async (c) => {
  const user = c.get("user");
  if (!user) {
    return c.json({ error: "Unauthorized" }, 401);
  }

  const eventId = c.req.param("id");

  // Check if user owns the event
  const existingEvent = await db.event.findFirst({
    where: { id: eventId, userId: user.id },
  });

  if (!existingEvent) {
    return c.json({ error: "Event not found" }, 404);
  }

  await db.event.delete({ where: { id: eventId } });

  return c.json({ success: true });
});

// POST /api/events/:id/join - Request to join event (auto-accepts)
eventsRouter.post("/:id/join", async (c) => {
  const user = c.get("user");
  if (!user) {
    return c.json({ error: "Unauthorized" }, 401);
  }

  const eventId = c.req.param("id");
  const body = await c.req.json();
  const parsed = joinEventRequestSchema.safeParse(body);

  if (!parsed.success) {
    return c.json({ error: "Invalid request", details: parsed.error }, 400);
  }

  // Check if event exists and user can see it
  const event = await db.event.findUnique({
    where: { id: eventId },
    include: { user: true },
  });

  if (!event) {
    return c.json({ error: "Event not found" }, 404);
  }

  // Check if already requested
  const existingRequest = await db.eventJoinRequest.findUnique({
    where: { eventId_userId: { eventId, userId: user.id } },
  });

  if (existingRequest) {
    // If already exists but not accepted, update to accepted
    if (existingRequest.status !== "accepted") {
      const updatedRequest = await db.eventJoinRequest.update({
        where: { id: existingRequest.id },
        data: { status: "accepted" },
      });
      return c.json({
        success: true,
        joinRequest: { id: updatedRequest.id, status: updatedRequest.status },
        autoAccepted: true,
      });
    }
    return c.json({ error: "Already attending this event" }, 400);
  }

  // Create join request with auto-accepted status
  const joinRequest = await db.eventJoinRequest.create({
    data: {
      eventId,
      userId: user.id,
      message: parsed.data.message,
      status: "accepted", // Auto-accept
    },
  });

  // Notify event owner that someone is attending
  await db.notification.create({
    data: {
      userId: event.userId,
      type: "join_request",
      title: "New Attendee",
      body: `${user.name ?? user.email} is attending: ${event.title}`,
      data: JSON.stringify({ eventId, requestId: joinRequest.id }),
    },
  });

  return c.json({
    success: true,
    joinRequest: { id: joinRequest.id, status: joinRequest.status },
    autoAccepted: true,
  });
});

// PUT /api/events/:eventId/join/:requestId - Accept/reject join request
eventsRouter.put("/:eventId/join/:requestId", async (c) => {
  const user = c.get("user");
  if (!user) {
    return c.json({ error: "Unauthorized" }, 401);
  }

  const eventId = c.req.param("eventId");
  const requestId = c.req.param("requestId");
  const body = await c.req.json();
  const parsed = updateJoinRequestSchema.safeParse(body);

  if (!parsed.success) {
    return c.json({ error: "Invalid request", details: parsed.error }, 400);
  }

  // Check if user owns the event
  const event = await db.event.findFirst({
    where: { id: eventId, userId: user.id },
  });

  if (!event) {
    return c.json({ error: "Event not found" }, 404);
  }

  const joinRequest = await db.eventJoinRequest.update({
    where: { id: requestId },
    data: { status: parsed.data.status },
    include: { user: true },
  });

  // Notify requester
  await db.notification.create({
    data: {
      userId: joinRequest.userId,
      type: "request_accepted",
      title: parsed.data.status === "accepted" ? "Request Accepted" : "Request Declined",
      body:
        parsed.data.status === "accepted"
          ? `You're in! ${user.name ?? user.email} accepted your request to join: ${event.title}`
          : `${user.name ?? user.email} declined your request to join: ${event.title}`,
      data: JSON.stringify({ eventId }),
    },
  });

  return c.json({ success: true });
});

// ============================================
// Event Comments
// ============================================

// Helper to serialize comment
const serializeComment = (comment: {
  id: string;
  eventId: string;
  userId: string;
  content: string;
  imageUrl: string | null;
  createdAt: Date;
  updatedAt: Date;
  user: { id: string; name: string | null; image: string | null };
}) => ({
  ...comment,
  createdAt: comment.createdAt.toISOString(),
  updatedAt: comment.updatedAt.toISOString(),
});

// GET /api/events/:id/comments - Get event comments
eventsRouter.get("/:id/comments", async (c) => {
  const user = c.get("user");
  if (!user) {
    return c.json({ error: "Unauthorized" }, 401);
  }

  const eventId = c.req.param("id");

  // Check if event exists
  const event = await db.event.findUnique({
    where: { id: eventId },
  });

  if (!event) {
    return c.json({ error: "Event not found" }, 404);
  }

  const comments = await db.eventComment.findMany({
    where: { eventId },
    include: {
      user: { select: { id: true, name: true, image: true } },
    },
    orderBy: { createdAt: "asc" },
  });

  return c.json({ comments: comments.map(serializeComment) });
});

// POST /api/events/:id/comments - Create comment
eventsRouter.post("/:id/comments", async (c) => {
  const user = c.get("user");
  if (!user) {
    return c.json({ error: "Unauthorized" }, 401);
  }

  const eventId = c.req.param("id");
  const body = await c.req.json();
  const parsed = createCommentRequestSchema.safeParse(body);

  if (!parsed.success) {
    return c.json({ error: "Invalid request", details: parsed.error }, 400);
  }

  // Check if event exists
  const event = await db.event.findUnique({
    where: { id: eventId },
    include: { user: true },
  });

  if (!event) {
    return c.json({ error: "Event not found" }, 404);
  }

  const comment = await db.eventComment.create({
    data: {
      eventId,
      userId: user.id,
      content: parsed.data.content,
      imageUrl: parsed.data.imageUrl,
    },
    include: {
      user: { select: { id: true, name: true, image: true } },
    },
  });

  // Notify event owner if someone else commented
  if (event.userId !== user.id) {
    await db.notification.create({
      data: {
        userId: event.userId,
        type: "new_comment",
        title: "New Comment",
        body: `${user.name ?? user.email} commented on your event: ${event.title}`,
        data: JSON.stringify({ eventId, commentId: comment.id }),
      },
    });
  }

  return c.json({ comment: serializeComment(comment) });
});

// DELETE /api/events/:eventId/comments/:commentId - Delete comment
eventsRouter.delete("/:eventId/comments/:commentId", async (c) => {
  const user = c.get("user");
  if (!user) {
    return c.json({ error: "Unauthorized" }, 401);
  }

  const eventId = c.req.param("eventId");
  const commentId = c.req.param("commentId");

  // Check if comment exists and belongs to user or event owner
  const comment = await db.eventComment.findUnique({
    where: { id: commentId },
    include: { event: true },
  });

  if (!comment) {
    return c.json({ error: "Comment not found" }, 404);
  }

  // Only allow deletion by comment author or event owner
  if (comment.userId !== user.id && comment.event.userId !== user.id) {
    return c.json({ error: "Unauthorized" }, 403);
  }

  await db.eventComment.delete({ where: { id: commentId } });

  return c.json({ success: true });
});

// ============================================
// Event Interest (Quick Reactions)
// ============================================

// POST /api/events/:id/interest - Mark interest in event
eventsRouter.post("/:id/interest", async (c) => {
  const user = c.get("user");
  if (!user) {
    return c.json({ error: "Unauthorized" }, 401);
  }

  const eventId = c.req.param("id");

  // Check if event exists
  const event = await db.event.findUnique({
    where: { id: eventId },
    include: { user: true },
  });

  if (!event) {
    return c.json({ error: "Event not found" }, 404);
  }

  // Check if already interested
  const existingInterest = await db.eventInterest.findUnique({
    where: { eventId_userId: { eventId, userId: user.id } },
  });

  if (existingInterest) {
    return c.json({ error: "Already interested" }, 400);
  }

  // Create interest
  const interest = await db.eventInterest.create({
    data: {
      eventId,
      userId: user.id,
    },
  });

  // Notify event owner
  if (event.userId !== user.id) {
    await db.notification.create({
      data: {
        userId: event.userId,
        type: "event_interest",
        title: "Someone's Interested",
        body: `${user.name ?? user.email} is interested in: ${event.title}`,
        data: JSON.stringify({ eventId }),
      },
    });
  }

  return c.json({ success: true, interestId: interest.id });
});

// DELETE /api/events/:id/interest - Remove interest in event
eventsRouter.delete("/:id/interest", async (c) => {
  const user = c.get("user");
  if (!user) {
    return c.json({ error: "Unauthorized" }, 401);
  }

  const eventId = c.req.param("id");

  await db.eventInterest.deleteMany({
    where: { eventId, userId: user.id },
  });

  return c.json({ success: true });
});

// GET /api/events/:id/interests - Get interested users for event
eventsRouter.get("/:id/interests", async (c) => {
  const user = c.get("user");
  if (!user) {
    return c.json({ error: "Unauthorized" }, 401);
  }

  const eventId = c.req.param("id");

  const interests = await db.eventInterest.findMany({
    where: { eventId },
    include: {
      user: { select: { id: true, name: true, image: true } },
    },
    orderBy: { createdAt: "desc" },
  });

  return c.json({
    interests: interests.map((i) => ({
      id: i.id,
      userId: i.userId,
      user: i.user,
      createdAt: i.createdAt.toISOString(),
    })),
  });
});

// ============================================
// Who's Free Discovery
// ============================================

// GET /api/events/whos-free?date=YYYY-MM-DD - Get friends who are free on a date
eventsRouter.get("/whos-free", async (c) => {
  const user = c.get("user");
  if (!user) {
    return c.json({ error: "Unauthorized" }, 401);
  }

  const dateStr = c.req.query("date");
  if (!dateStr) {
    return c.json({ error: "Date parameter required" }, 400);
  }

  const targetDate = new Date(dateStr);
  const startOfDay = new Date(targetDate);
  startOfDay.setHours(0, 0, 0, 0);
  const endOfDay = new Date(targetDate);
  endOfDay.setHours(23, 59, 59, 999);

  // Get blocked user IDs
  const [blockedByMe, blockedMe] = await Promise.all([
    getBlockedUserIds(user.id),
    getBlockedByUserIds(user.id),
  ]);
  const allBlockedIds = [...new Set([...blockedByMe, ...blockedMe])];

  // Get all friends
  const friendships = await db.friendship.findMany({
    where: {
      userId: user.id,
      isBlocked: false,
      friendId: { notIn: allBlockedIds },
    },
    include: {
      friend: { select: { id: true, name: true, email: true, image: true } },
      groupMemberships: {
        include: {
          group: { select: { id: true, name: true, color: true } },
        },
      },
    },
  });

  // Get all friends who have events on this date
  const friendIds = friendships.map((f) => f.friendId);
  const busyFriendEvents = await db.event.findMany({
    where: {
      userId: { in: friendIds },
      startTime: { gte: startOfDay, lte: endOfDay },
    },
    select: { userId: true },
  });

  const busyFriendIds = new Set(busyFriendEvents.map((e) => e.userId));

  // Also check work schedules for friends
  const dayOfWeek = targetDate.getDay();
  const workSchedules = await db.workSchedule.findMany({
    where: {
      userId: { in: friendIds },
      dayOfWeek,
      isEnabled: true,
    },
    select: { userId: true, label: true },
  });

  // Track which friends are busy due to work
  const workingFriendIds = new Set(workSchedules.map((ws) => ws.userId));
  const workLabels = new Map(workSchedules.map((ws) => [ws.userId, ws.label]));

  // Add friends with work schedules to busy set
  workSchedules.forEach((ws) => busyFriendIds.add(ws.userId));

  // Categorize friends
  const freeFriends = friendships.filter((f) => !busyFriendIds.has(f.friendId));
  const busyFriends = friendships.filter((f) => busyFriendIds.has(f.friendId));

  return c.json({
    date: dateStr,
    freeFriends: freeFriends.map((f) => ({
      friendshipId: f.id,
      friend: f.friend,
      groups: f.groupMemberships.map((gm) => gm.group),
    })),
    busyFriends: busyFriends.map((f) => ({
      friendshipId: f.id,
      friend: f.friend,
      groups: f.groupMemberships.map((gm) => gm.group),
      isWorking: workingFriendIds.has(f.friendId),
      workLabel: workLabels.get(f.friendId) ?? null,
    })),
  });
});

// ============================================
// Shared Availability View
// ============================================

// POST /api/events/shared-availability - Find overlapping free times
eventsRouter.post("/shared-availability", async (c) => {
  const user = c.get("user");
  if (!user) {
    return c.json({ error: "Unauthorized" }, 401);
  }

  const body = await c.req.json();
  const { friendIds, startDate, endDate } = body as {
    friendIds: string[];
    startDate: string;
    endDate: string;
  };

  if (!friendIds || friendIds.length === 0) {
    return c.json({ error: "Friend IDs required" }, 400);
  }

  const start = new Date(startDate);
  const end = new Date(endDate);

  // Get blocked user IDs
  const [blockedByMe, blockedMe] = await Promise.all([
    getBlockedUserIds(user.id),
    getBlockedByUserIds(user.id),
  ]);
  const allBlockedIds = [...new Set([...blockedByMe, ...blockedMe])];

  // Verify these are actually friends
  const friendships = await db.friendship.findMany({
    where: {
      userId: user.id,
      friendId: { in: friendIds, notIn: allBlockedIds },
      isBlocked: false,
    },
  });

  const validFriendIds = friendships.map((f) => f.friendId);

  // Get all events for user and friends in the date range
  const allUserIds = [user.id, ...validFriendIds];
  const events = await db.event.findMany({
    where: {
      userId: { in: allUserIds },
      startTime: { gte: start, lte: end },
    },
    select: {
      userId: true,
      startTime: true,
      endTime: true,
      title: true,
    },
  });

  // Group events by date
  const eventsByDate: Record<string, { userId: string; title: string }[]> = {};

  events.forEach((event) => {
    const dateKey = event.startTime.toISOString().split("T")[0];
    if (!eventsByDate[dateKey]) {
      eventsByDate[dateKey] = [];
    }
    eventsByDate[dateKey].push({ userId: event.userId, title: event.title });
  });

  // Find dates where everyone is free
  const freeDates: string[] = [];
  const currentDate = new Date(start);

  while (currentDate <= end) {
    const dateKey = currentDate.toISOString().split("T")[0];
    const eventsOnDate = eventsByDate[dateKey] || [];
    const busyUserIds = new Set(eventsOnDate.map((e) => e.userId));

    // Check if all users (including current user) are free
    const allFree = !allUserIds.some((id) => busyUserIds.has(id));

    if (allFree) {
      freeDates.push(dateKey);
    }

    currentDate.setDate(currentDate.getDate() + 1);
  }

  return c.json({
    freeDates,
    eventsByDate,
  });
});

// ============================================
// Location-Based Events
// ============================================

// GET /api/events/nearby?location=string - Get friends with events near a location
eventsRouter.get("/nearby", async (c) => {
  const user = c.get("user");
  if (!user) {
    return c.json({ error: "Unauthorized" }, 401);
  }

  const locationQuery = c.req.query("location")?.toLowerCase() || "";

  // Get blocked user IDs
  const [blockedByMe, blockedMe] = await Promise.all([
    getBlockedUserIds(user.id),
    getBlockedByUserIds(user.id),
  ]);
  const allBlockedIds = [...new Set([...blockedByMe, ...blockedMe])];

  // Get friendships
  const friendships = await db.friendship.findMany({
    where: {
      userId: user.id,
      isBlocked: false,
      friendId: { notIn: allBlockedIds },
    },
  });

  const friendIds = friendships.map((f) => f.friendId);

  // Get today's date range
  const now = new Date();
  const endOfDay = new Date();
  endOfDay.setHours(23, 59, 59, 999);

  // Get events from friends today that match location
  const events = await db.event.findMany({
    where: {
      userId: { in: friendIds },
      startTime: { gte: now, lte: endOfDay },
      location: { not: null },
    },
    include: {
      user: { select: { id: true, name: true, image: true } },
    },
  });

  // Filter by location if query provided, otherwise return all
  const filteredEvents = locationQuery
    ? events.filter((e) => e.location?.toLowerCase().includes(locationQuery))
    : events;

  // Group by location
  const eventsByLocation: Record<
    string,
    Array<{
      id: string;
      title: string;
      startTime: string;
      user: { id: string; name: string | null; image: string | null };
    }>
  > = {};

  filteredEvents.forEach((event) => {
    const loc = event.location || "Unknown";
    if (!eventsByLocation[loc]) {
      eventsByLocation[loc] = [];
    }
    eventsByLocation[loc].push({
      id: event.id,
      title: event.title,
      startTime: event.startTime.toISOString(),
      user: event.user,
    });
  });

  return c.json({ eventsByLocation });
});

// ============================================
// Smart Suggestions
// ============================================

// GET /api/events/suggestions - Get friend reconnection suggestions
eventsRouter.get("/suggestions", async (c) => {
  const user = c.get("user");
  if (!user) {
    return c.json({ error: "Unauthorized" }, 401);
  }

  // Get blocked user IDs
  const [blockedByMe, blockedMe] = await Promise.all([
    getBlockedUserIds(user.id),
    getBlockedByUserIds(user.id),
  ]);
  const allBlockedIds = [...new Set([...blockedByMe, ...blockedMe])];

  // Get all friendships with group info
  const friendships = await db.friendship.findMany({
    where: {
      userId: user.id,
      isBlocked: false,
      friendId: { notIn: allBlockedIds },
    },
    include: {
      friend: { select: { id: true, name: true, image: true } },
      groupMemberships: {
        include: {
          group: { select: { id: true, name: true, color: true } },
        },
      },
    },
  });

  // Get hangout history for the last 90 days
  const ninetyDaysAgo = new Date();
  ninetyDaysAgo.setDate(ninetyDaysAgo.getDate() - 90);

  const hangoutHistory = await db.hangoutHistory.findMany({
    where: {
      userId: user.id,
      hangoutDate: { gte: ninetyDaysAgo },
    },
  });

  // Get events where user and friends both attended (proxy for hangouts)
  const userJoinRequests = await db.eventJoinRequest.findMany({
    where: {
      userId: user.id,
      status: "accepted",
      event: {
        startTime: { gte: ninetyDaysAgo },
      },
    },
    include: {
      event: {
        include: {
          joinRequests: {
            where: { status: "accepted" },
            select: { userId: true },
          },
        },
      },
    },
  });

  // Count hangouts per friend
  const hangoutCounts: Record<string, { count: number; lastHangout: Date | null }> = {};

  friendships.forEach((f) => {
    hangoutCounts[f.friendId] = { count: 0, lastHangout: null };
  });

  hangoutHistory.forEach((h) => {
    if (hangoutCounts[h.friendId]) {
      hangoutCounts[h.friendId].count++;
      if (!hangoutCounts[h.friendId].lastHangout || h.hangoutDate > hangoutCounts[h.friendId].lastHangout!) {
        hangoutCounts[h.friendId].lastHangout = h.hangoutDate;
      }
    }
  });

  // Also count shared event attendance
  userJoinRequests.forEach((jr) => {
    jr.event.joinRequests.forEach((otherJr) => {
      if (otherJr.userId !== user.id && hangoutCounts[otherJr.userId]) {
        hangoutCounts[otherJr.userId].count++;
        const eventDate = jr.event.startTime;
        if (!hangoutCounts[otherJr.userId].lastHangout || eventDate > hangoutCounts[otherJr.userId].lastHangout!) {
          hangoutCounts[otherJr.userId].lastHangout = eventDate;
        }
      }
    });
  });

  // Find friends who haven't been seen in a while (no hangouts in 3+ weeks)
  const threeWeeksAgo = new Date();
  threeWeeksAgo.setDate(threeWeeksAgo.getDate() - 21);

  const suggestions = friendships
    .map((f) => {
      const hangoutInfo = hangoutCounts[f.friendId];
      const daysSinceHangout = hangoutInfo.lastHangout
        ? Math.floor((Date.now() - hangoutInfo.lastHangout.getTime()) / (1000 * 60 * 60 * 24))
        : 999;

      return {
        friend: f.friend,
        friendshipId: f.id,
        groups: f.groupMemberships.map((gm) => gm.group),
        hangoutCount: hangoutInfo.count,
        lastHangout: hangoutInfo.lastHangout?.toISOString() || null,
        daysSinceHangout,
        needsReconnection: !hangoutInfo.lastHangout || hangoutInfo.lastHangout < threeWeeksAgo,
      };
    })
    .filter((s) => s.needsReconnection)
    .sort((a, b) => b.daysSinceHangout - a.daysSinceHangout)
    .slice(0, 5);

  return c.json({ suggestions });
});

// ============================================
// Event Templates
// ============================================

// GET /api/events/templates - Get user's event templates
eventsRouter.get("/templates", async (c) => {
  const user = c.get("user");
  if (!user) {
    return c.json({ error: "Unauthorized" }, 401);
  }

  // Get user's custom templates
  let templates = await db.eventTemplate.findMany({
    where: { userId: user.id },
    orderBy: { name: "asc" },
  });

  // If no templates, seed with defaults
  if (templates.length === 0) {
    const defaultTemplates = [
      { name: "Coffee", emoji: "☕", duration: 60, description: "Quick coffee catch-up" },
      { name: "Lunch", emoji: "🍽️", duration: 90, description: "Lunch hangout" },
      { name: "Workout", emoji: "💪", duration: 60, description: "Gym or workout session" },
      { name: "Movie Night", emoji: "🎬", duration: 180, description: "Movie time" },
      { name: "Game Night", emoji: "🎮", duration: 180, description: "Gaming session" },
      { name: "Walk", emoji: "🚶", duration: 45, description: "Walk and talk" },
      { name: "Drinks", emoji: "🍻", duration: 120, description: "Drinks at a bar" },
      { name: "Dinner", emoji: "🍝", duration: 120, description: "Dinner together" },
    ];

    await db.eventTemplate.createMany({
      data: defaultTemplates.map((t) => ({
        ...t,
        userId: user.id,
        isDefault: true,
      })),
    });

    templates = await db.eventTemplate.findMany({
      where: { userId: user.id },
      orderBy: { name: "asc" },
    });
  }

  return c.json({
    templates: templates.map((t) => ({
      id: t.id,
      name: t.name,
      emoji: t.emoji,
      duration: t.duration,
      description: t.description,
      isDefault: t.isDefault,
    })),
  });
});

// POST /api/events/templates - Create custom template
eventsRouter.post("/templates", async (c) => {
  const user = c.get("user");
  if (!user) {
    return c.json({ error: "Unauthorized" }, 401);
  }

  const body = await c.req.json();
  const { name, emoji, duration, description } = body as {
    name: string;
    emoji: string;
    duration?: number;
    description?: string;
  };

  if (!name || !emoji) {
    return c.json({ error: "Name and emoji required" }, 400);
  }

  const template = await db.eventTemplate.create({
    data: {
      name,
      emoji,
      duration: duration || 60,
      description,
      userId: user.id,
      isDefault: false,
    },
  });

  return c.json({
    template: {
      id: template.id,
      name: template.name,
      emoji: template.emoji,
      duration: template.duration,
      description: template.description,
      isDefault: template.isDefault,
    },
  });
});

// DELETE /api/events/templates/:id - Delete custom template
eventsRouter.delete("/templates/:id", async (c) => {
  const user = c.get("user");
  if (!user) {
    return c.json({ error: "Unauthorized" }, 401);
  }

  const templateId = c.req.param("id");

  const template = await db.eventTemplate.findFirst({
    where: { id: templateId, userId: user.id },
  });

  if (!template) {
    return c.json({ error: "Template not found" }, 404);
  }

  await db.eventTemplate.delete({ where: { id: templateId } });

  return c.json({ success: true });
});

// ============================================
// Hangout Streaks
// ============================================

// GET /api/events/streaks - Get hangout streaks with friends
eventsRouter.get("/streaks", async (c) => {
  const user = c.get("user");
  if (!user) {
    return c.json({ error: "Unauthorized" }, 401);
  }

  // Get blocked user IDs
  const [blockedByMe, blockedMe] = await Promise.all([
    getBlockedUserIds(user.id),
    getBlockedByUserIds(user.id),
  ]);
  const allBlockedIds = [...new Set([...blockedByMe, ...blockedMe])];

  // Get all friendships
  const friendships = await db.friendship.findMany({
    where: {
      userId: user.id,
      isBlocked: false,
      friendId: { notIn: allBlockedIds },
    },
    include: {
      friend: { select: { id: true, name: true, image: true } },
    },
  });

  // Get hangout history
  const hangoutHistory = await db.hangoutHistory.findMany({
    where: { userId: user.id },
    orderBy: { hangoutDate: "desc" },
  });

  // Calculate streaks per friend
  const streaksByFriend: Record<
    string,
    {
      totalHangouts: number;
      lastHangout: Date | null;
      currentStreak: number; // consecutive weeks with at least one hangout
      longestStreak: number;
    }
  > = {};

  friendships.forEach((f) => {
    const friendHangouts = hangoutHistory
      .filter((h) => h.friendId === f.friendId)
      .sort((a, b) => b.hangoutDate.getTime() - a.hangoutDate.getTime());

    const totalHangouts = friendHangouts.length;
    const lastHangout = friendHangouts[0]?.hangoutDate || null;

    // Calculate weekly streak
    let currentStreak = 0;
    let longestStreak = 0;

    if (friendHangouts.length > 0) {
      const now = new Date();
      const weekMs = 7 * 24 * 60 * 60 * 1000;

      // Group hangouts by week
      const weeklyHangouts = new Set<number>();
      friendHangouts.forEach((h) => {
        const weekNumber = Math.floor(h.hangoutDate.getTime() / weekMs);
        weeklyHangouts.add(weekNumber);
      });

      const currentWeek = Math.floor(now.getTime() / weekMs);
      const sortedWeeks = Array.from(weeklyHangouts).sort((a, b) => b - a);

      // Count consecutive weeks from current/last week
      let streak = 0;
      let expectedWeek = sortedWeeks[0] === currentWeek ? currentWeek : sortedWeeks[0];

      for (const week of sortedWeeks) {
        if (week === expectedWeek || week === expectedWeek - 1) {
          streak++;
          expectedWeek = week - 1;
        } else {
          break;
        }
      }

      currentStreak = streak;

      // Calculate longest streak
      let tempStreak = 1;
      for (let i = 1; i < sortedWeeks.length; i++) {
        if (sortedWeeks[i - 1] - sortedWeeks[i] === 1) {
          tempStreak++;
        } else {
          longestStreak = Math.max(longestStreak, tempStreak);
          tempStreak = 1;
        }
      }
      longestStreak = Math.max(longestStreak, tempStreak);
    }

    streaksByFriend[f.friendId] = {
      totalHangouts,
      lastHangout,
      currentStreak,
      longestStreak,
    };
  });

  const streaks = friendships
    .map((f) => ({
      friend: f.friend,
      friendshipId: f.id,
      ...streaksByFriend[f.friendId],
      lastHangout: streaksByFriend[f.friendId].lastHangout?.toISOString() || null,
    }))
    .filter((s) => s.totalHangouts > 0)
    .sort((a, b) => b.currentStreak - a.currentStreak);

  return c.json({ streaks });
});

// POST /api/events/hangout - Record a hangout
eventsRouter.post("/hangout", async (c) => {
  const user = c.get("user");
  if (!user) {
    return c.json({ error: "Unauthorized" }, 401);
  }

  const body = await c.req.json();
  const { friendId, eventId, eventTitle, hangoutDate } = body as {
    friendId: string;
    eventId?: string;
    eventTitle?: string;
    hangoutDate?: string;
  };

  if (!friendId) {
    return c.json({ error: "Friend ID required" }, 400);
  }

  // Verify friendship exists
  const friendship = await db.friendship.findFirst({
    where: {
      userId: user.id,
      friendId,
      isBlocked: false,
    },
  });

  if (!friendship) {
    return c.json({ error: "Friendship not found" }, 404);
  }

  const hangout = await db.hangoutHistory.create({
    data: {
      userId: user.id,
      friendId,
      eventId,
      eventTitle,
      hangoutDate: hangoutDate ? new Date(hangoutDate) : new Date(),
    },
  });

  return c.json({
    success: true,
    hangout: {
      id: hangout.id,
      friendId: hangout.friendId,
      eventTitle: hangout.eventTitle,
      hangoutDate: hangout.hangoutDate.toISOString(),
    },
  });
});

// ============================================
// Event Photos / Memories
// ============================================

// GET /api/events/:id/photos - Get event photos
eventsRouter.get("/:id/photos", async (c) => {
  const user = c.get("user");
  if (!user) {
    return c.json({ error: "Unauthorized" }, 401);
  }

  const eventId = c.req.param("id");

  // Check if event exists
  const event = await db.event.findUnique({
    where: { id: eventId },
  });

  if (!event) {
    return c.json({ error: "Event not found" }, 404);
  }

  const photos = await db.eventPhoto.findMany({
    where: { eventId },
    include: {
      user: { select: { id: true, name: true, image: true } },
    },
    orderBy: { createdAt: "desc" },
  });

  return c.json({
    photos: photos.map((p) => ({
      id: p.id,
      eventId: p.eventId,
      userId: p.userId,
      imageUrl: p.imageUrl,
      caption: p.caption,
      createdAt: p.createdAt.toISOString(),
      user: p.user,
    })),
  });
});

// POST /api/events/:id/photos - Add photo to event
eventsRouter.post("/:id/photos", async (c) => {
  const user = c.get("user");
  if (!user) {
    return c.json({ error: "Unauthorized" }, 401);
  }

  const eventId = c.req.param("id");
  const body = await c.req.json();
  const { imageUrl, caption } = body as { imageUrl: string; caption?: string };

  if (!imageUrl) {
    return c.json({ error: "Image URL is required" }, 400);
  }

  // Check if event exists
  const event = await db.event.findUnique({
    where: { id: eventId },
    include: { user: true },
  });

  if (!event) {
    return c.json({ error: "Event not found" }, 404);
  }

  // Only allow photos for past events or events happening today
  const now = new Date();
  const eventDate = new Date(event.startTime);
  const today = new Date(now.getFullYear(), now.getMonth(), now.getDate());
  const eventDay = new Date(eventDate.getFullYear(), eventDate.getMonth(), eventDate.getDate());

  if (eventDay > today) {
    return c.json({ error: "Cannot add photos to future events" }, 400);
  }

  const photo = await db.eventPhoto.create({
    data: {
      eventId,
      userId: user.id,
      imageUrl,
      caption,
    },
    include: {
      user: { select: { id: true, name: true, image: true } },
    },
  });

  // Notify event owner if someone else added a photo
  if (event.userId !== user.id) {
    await db.notification.create({
      data: {
        userId: event.userId,
        type: "new_photo",
        title: "New Photo",
        body: `${user.name ?? user.email} added a photo to: ${event.title}`,
        data: JSON.stringify({ eventId, photoId: photo.id }),
      },
    });
  }

  return c.json({
    photo: {
      id: photo.id,
      eventId: photo.eventId,
      userId: photo.userId,
      imageUrl: photo.imageUrl,
      caption: photo.caption,
      createdAt: photo.createdAt.toISOString(),
      user: photo.user,
    },
  });
});

// DELETE /api/events/:eventId/photos/:photoId - Delete photo
eventsRouter.delete("/:eventId/photos/:photoId", async (c) => {
  const user = c.get("user");
  if (!user) {
    return c.json({ error: "Unauthorized" }, 401);
  }

  const eventId = c.req.param("eventId");
  const photoId = c.req.param("photoId");

  // Check if photo exists and belongs to user or event owner
  const photo = await db.eventPhoto.findUnique({
    where: { id: photoId },
    include: { event: true },
  });

  if (!photo) {
    return c.json({ error: "Photo not found" }, 404);
  }

  // Only allow deletion by photo uploader or event owner
  if (photo.userId !== user.id && photo.event.userId !== user.id) {
    return c.json({ error: "Unauthorized" }, 403);
  }

  await db.eventPhoto.delete({ where: { id: photoId } });

  return c.json({ success: true });
});

// ============================================
// Suggested Times
// ============================================

// POST /api/events/suggested-times - Get suggested times when friends are free
eventsRouter.post("/suggested-times", async (c) => {
  const user = c.get("user");
  if (!user) {
    return c.json({ error: "Unauthorized" }, 401);
  }

  const body = await c.req.json();
  const { friendIds, dateRange, duration = 60 } = body as {
    friendIds: string[];
    dateRange: { start: string; end: string };
    duration?: number;
  };

  if (!friendIds || friendIds.length === 0 || !dateRange) {
    return c.json({ error: "Friend IDs and date range are required" }, 400);
  }

  const rangeStart = new Date(dateRange.start);
  const rangeEnd = new Date(dateRange.end);

  // Get blocked user IDs
  const [blockedByMe, blockedMe] = await Promise.all([
    getBlockedUserIds(user.id),
    getBlockedByUserIds(user.id),
  ]);
  const allBlockedIds = [...new Set([...blockedByMe, ...blockedMe])];

  // Verify these are actually friends and get their info
  const friendships = await db.friendship.findMany({
    where: {
      userId: user.id,
      friendId: { in: friendIds, notIn: allBlockedIds },
      isBlocked: false,
    },
    include: {
      friend: {
        select: { id: true, name: true, image: true },
      },
    },
  });

  const validFriends = friendships.map((f) => f.friend);
  const validFriendIds = validFriends.map((f) => f.id);
  const allUserIds = [user.id, ...validFriendIds];

  // Get all events in the date range for all users
  const events = await db.event.findMany({
    where: {
      userId: { in: allUserIds },
      startTime: { gte: rangeStart, lte: rangeEnd },
    },
  });

  // Get work schedules for all users
  const workSchedules = await db.workSchedule.findMany({
    where: {
      userId: { in: allUserIds },
      isEnabled: true,
    },
  });

  // Build busy times per user per day
  // Key: "userId-YYYY-MM-DD", Value: array of busy periods in minutes from midnight
  interface BusyPeriod {
    start: number; // minutes from midnight
    end: number;
  }
  const busyTimesMap: Record<string, BusyPeriod[]> = {};

  const getKey = (userId: string, date: Date) => {
    return `${userId}-${date.toISOString().split("T")[0]}`;
  };

  // Initialize busy times for all users for all days in range
  const currentDate = new Date(rangeStart);
  while (currentDate <= rangeEnd) {
    for (const userId of allUserIds) {
      const key = getKey(userId, currentDate);
      busyTimesMap[key] = [];
    }
    currentDate.setDate(currentDate.getDate() + 1);
  }

  // Add work schedules as busy times
  for (const ws of workSchedules) {
    if (!ws.startTime || !ws.endTime) continue;
    const [startHour, startMin] = ws.startTime.split(":").map(Number);
    const [endHour, endMin] = ws.endTime.split(":").map(Number);
    const startMins = startHour * 60 + startMin;
    const endMins = endHour * 60 + endMin;

    // Apply to all matching days in the range
    const checkDate = new Date(rangeStart);
    while (checkDate <= rangeEnd) {
      if (checkDate.getDay() === ws.dayOfWeek) {
        const key = getKey(ws.userId, checkDate);
        if (busyTimesMap[key]) {
          busyTimesMap[key].push({ start: startMins, end: endMins });
        }
      }
      checkDate.setDate(checkDate.getDate() + 1);
    }
  }

  // Add events as busy times
  for (const event of events) {
    const eventStart = new Date(event.startTime);
    const eventEnd = event.endTime
      ? new Date(event.endTime)
      : new Date(eventStart.getTime() + 60 * 60 * 1000); // Default 1 hour

    const key = getKey(event.userId, eventStart);
    if (busyTimesMap[key]) {
      const startMins = eventStart.getHours() * 60 + eventStart.getMinutes();
      const endMins = eventEnd.getHours() * 60 + eventEnd.getMinutes();
      busyTimesMap[key].push({ start: startMins, end: Math.max(endMins, startMins + 30) });
    }
  }

  // Find available time slots
  const slots: Array<{
    start: string;
    end: string;
    availableFriends: Array<{ id: string; name: string | null; image: string | null }>;
    totalAvailable: number;
  }> = [];

  const dayStart = 9 * 60; // 9 AM
  const dayEnd = 21 * 60; // 9 PM
  const slotDuration = duration; // minutes

  // Check each day in the range
  const iterDate = new Date(rangeStart);
  while (iterDate <= rangeEnd) {
    // Skip past dates
    const now = new Date();
    if (iterDate < new Date(now.toDateString())) {
      iterDate.setDate(iterDate.getDate() + 1);
      continue;
    }

    const dateStr = iterDate.toISOString().split("T")[0];

    // Check time slots throughout the day
    for (let slotStart = dayStart; slotStart + slotDuration <= dayEnd; slotStart += 60) {
      const slotEnd = slotStart + slotDuration;

      // Find which friends are available during this slot
      const availableFriends: Array<{ id: string; name: string | null; image: string | null }> = [];

      for (const friend of validFriends) {
        const key = getKey(friend.id, iterDate);
        const busyPeriods = busyTimesMap[key] || [];

        // Check if this slot overlaps with any busy period
        const isBusy = busyPeriods.some(
          (busy) => !(slotEnd <= busy.start || slotStart >= busy.end)
        );

        if (!isBusy) {
          availableFriends.push(friend);
        }
      }

      // Only include slots where at least one friend is available
      if (availableFriends.length > 0) {
        const slotStartDate = new Date(iterDate);
        slotStartDate.setHours(Math.floor(slotStart / 60), slotStart % 60, 0, 0);
        const slotEndDate = new Date(iterDate);
        slotEndDate.setHours(Math.floor(slotEnd / 60), slotEnd % 60, 0, 0);

        // Skip if this slot is in the past
        if (slotStartDate <= now) continue;

        slots.push({
          start: slotStartDate.toISOString(),
          end: slotEndDate.toISOString(),
          availableFriends,
          totalAvailable: availableFriends.length,
        });
      }
    }

    iterDate.setDate(iterDate.getDate() + 1);
  }

  // Sort by most friends available, then by date
  slots.sort((a, b) => {
    if (b.totalAvailable !== a.totalAvailable) {
      return b.totalAvailable - a.totalAvailable;
    }
    return new Date(a.start).getTime() - new Date(b.start).getTime();
  });

  // Return top 20 slots
  return c.json({ slots: slots.slice(0, 20) });
});

// ============================================
// Activity Feed (Social Activity)
// ============================================

// GET /api/events/activity-feed - Get friend activity feed
eventsRouter.get("/activity-feed", async (c) => {
  const user = c.get("user");
  if (!user) {
    return c.json({ error: "Unauthorized" }, 401);
  }

  const limit = parseInt(c.req.query("limit") || "30");
  const offset = parseInt(c.req.query("offset") || "0");

  // Get blocked user IDs (both directions)
  const [blockedByMe, blockedMe] = await Promise.all([
    getBlockedUserIds(user.id),
    getBlockedByUserIds(user.id),
  ]);
  const allBlockedIds = [...new Set([...blockedByMe, ...blockedMe])];

  // Get user's friendships
  const friendships = await db.friendship.findMany({
    where: {
      userId: user.id,
      isBlocked: false,
      friendId: { notIn: allBlockedIds },
    },
  });
  const friendIds = friendships.map((f) => f.friendId);

  if (friendIds.length === 0) {
    return c.json({ activities: [], hasMore: false });
  }

  // Get recent activities from friends:
  // 1. Events created by friends (visible to user)
  // 2. Friends joining events
  // 3. Friends commenting on events
  // 4. Friends adding photos to events

  const thirtyDaysAgo = new Date();
  thirtyDaysAgo.setDate(thirtyDaysAgo.getDate() - 30);

  // 1. Events created by friends
  const friendEvents = await db.event.findMany({
    where: {
      userId: { in: friendIds },
      createdAt: { gte: thirtyDaysAgo },
      OR: [
        { visibility: "all_friends" },
        {
          visibility: "specific_groups",
          groupVisibility: {
            some: {
              groupId: {
                in: friendships.flatMap((f) =>
                  (f as any).groupMemberships?.map((m: any) => m.groupId) || []
                ),
              },
            },
          },
        },
      ],
    },
    include: {
      user: { select: { id: true, name: true, email: true, image: true } },
    },
    orderBy: { createdAt: "desc" },
    take: 50,
  });

  // 2. Friends joining events (accepted join requests)
  const friendJoinRequests = await db.eventJoinRequest.findMany({
    where: {
      userId: { in: friendIds },
      status: "accepted",
      createdAt: { gte: thirtyDaysAgo },
    },
    include: {
      user: { select: { id: true, name: true, image: true } },
      event: {
        include: {
          user: { select: { id: true, name: true, image: true } },
        },
      },
    },
    orderBy: { createdAt: "desc" },
    take: 50,
  });

  // 3. Friends commenting on events
  const friendComments = await db.eventComment.findMany({
    where: {
      userId: { in: friendIds },
      createdAt: { gte: thirtyDaysAgo },
    },
    include: {
      user: { select: { id: true, name: true, image: true } },
      event: {
        include: {
          user: { select: { id: true, name: true, image: true } },
        },
      },
    },
    orderBy: { createdAt: "desc" },
    take: 50,
  });

  // 4. Friends adding photos
  const friendPhotos = await db.eventPhoto.findMany({
    where: {
      userId: { in: friendIds },
      createdAt: { gte: thirtyDaysAgo },
    },
    include: {
      user: { select: { id: true, name: true, image: true } },
      event: {
        include: {
          user: { select: { id: true, name: true, image: true } },
        },
      },
    },
    orderBy: { createdAt: "desc" },
    take: 50,
  });

  // Combine into activity items
  type ActivityItem = {
    id: string;
    type: "event_created" | "event_joined" | "event_commented" | "photo_added";
    timestamp: string;
    user: { id: string; name: string | null; image: string | null };
    event: {
      id: string;
      title: string;
      emoji: string;
      startTime: string;
      host: { id: string; name: string | null; image: string | null };
    };
    content?: string; // For comments
    imageUrl?: string; // For photos
  };

  const activities: ActivityItem[] = [];

  // Add event creation activities
  for (const event of friendEvents) {
    activities.push({
      id: `event-${event.id}`,
      type: "event_created",
      timestamp: event.createdAt.toISOString(),
      user: {
        id: event.user?.id || event.userId,
        name: event.user?.name || null,
        image: event.user?.image || null,
      },
      event: {
        id: event.id,
        title: event.title,
        emoji: event.emoji,
        startTime: event.startTime.toISOString(),
        host: {
          id: event.user?.id || event.userId,
          name: event.user?.name || null,
          image: event.user?.image || null,
        },
      },
    });
  }

  // Add join activities
  for (const jr of friendJoinRequests) {
    if (!jr.event) continue;
    activities.push({
      id: `join-${jr.id}`,
      type: "event_joined",
      timestamp: jr.createdAt.toISOString(),
      user: {
        id: jr.user.id,
        name: jr.user.name,
        image: jr.user.image,
      },
      event: {
        id: jr.event.id,
        title: jr.event.title,
        emoji: jr.event.emoji,
        startTime: jr.event.startTime.toISOString(),
        host: {
          id: jr.event.user?.id || jr.event.userId,
          name: jr.event.user?.name || null,
          image: jr.event.user?.image || null,
        },
      },
    });
  }

  // Add comment activities
  for (const comment of friendComments) {
    if (!comment.event) continue;
    activities.push({
      id: `comment-${comment.id}`,
      type: "event_commented",
      timestamp: comment.createdAt.toISOString(),
      user: {
        id: comment.user.id,
        name: comment.user.name,
        image: comment.user.image,
      },
      event: {
        id: comment.event.id,
        title: comment.event.title,
        emoji: comment.event.emoji,
        startTime: comment.event.startTime.toISOString(),
        host: {
          id: comment.event.user?.id || comment.event.userId,
          name: comment.event.user?.name || null,
          image: comment.event.user?.image || null,
        },
      },
      content: comment.content,
    });
  }

  // Add photo activities
  for (const photo of friendPhotos) {
    if (!photo.event) continue;
    activities.push({
      id: `photo-${photo.id}`,
      type: "photo_added",
      timestamp: photo.createdAt.toISOString(),
      user: {
        id: photo.user.id,
        name: photo.user.name,
        image: photo.user.image,
      },
      event: {
        id: photo.event.id,
        title: photo.event.title,
        emoji: photo.event.emoji,
        startTime: photo.event.startTime.toISOString(),
        host: {
          id: photo.event.user?.id || photo.event.userId,
          name: photo.event.user?.name || null,
          image: photo.event.user?.image || null,
        },
      },
      imageUrl: photo.imageUrl,
    });
  }

  // Sort by timestamp descending
  activities.sort((a, b) => new Date(b.timestamp).getTime() - new Date(a.timestamp).getTime());

  // Apply pagination
  const paginatedActivities = activities.slice(offset, offset + limit);
  const hasMore = offset + limit < activities.length;

  return c.json({ activities: paginatedActivities, hasMore });
});
