import { Hono } from "hono";
import { db } from "../db";
import { type AppType } from "../types";

export const notificationsRouter = new Hono<AppType>();

// GET /api/notifications - Get all notifications
notificationsRouter.get("/", async (c) => {
  const user = c.get("user");
  if (!user) {
    return c.json({ error: "Unauthorized" }, 401);
  }

  const notifications = await db.notification.findMany({
    where: { userId: user.id },
    orderBy: { createdAt: "desc" },
    take: 50,
  });

  const unreadCount = await db.notification.count({
    where: { userId: user.id, read: false },
  });

  return c.json({
    notifications: notifications.map((n) => ({
      ...n,
      createdAt: n.createdAt.toISOString(),
    })),
    unreadCount,
  });
});

// POST /api/notifications/register-token - Register push token
notificationsRouter.post("/register-token", async (c) => {
  const user = c.get("user");
  if (!user) {
    return c.json({ error: "Unauthorized" }, 401);
  }

  try {
    const body = await c.req.json();
    const { token, platform = "expo" } = body;

    if (!token) {
      return c.json({ error: "Token is required" }, 400);
    }

    // Upsert the push token
    await db.pushToken.upsert({
      where: {
        userId_token: {
          userId: user.id,
          token,
        },
      },
      update: {
        platform,
        updatedAt: new Date(),
      },
      create: {
        userId: user.id,
        token,
        platform,
      },
    });

    return c.json({ success: true });
  } catch (error) {
    console.error("Error registering push token:", error);
    return c.json({ error: "Failed to register push token" }, 500);
  }
});

// DELETE /api/notifications/unregister-token - Unregister push token
notificationsRouter.delete("/unregister-token", async (c) => {
  const user = c.get("user");
  if (!user) {
    return c.json({ error: "Unauthorized" }, 401);
  }

  try {
    const body = await c.req.json();
    const { token } = body;

    if (!token) {
      return c.json({ error: "Token is required" }, 400);
    }

    await db.pushToken.deleteMany({
      where: {
        userId: user.id,
        token,
      },
    });

    return c.json({ success: true });
  } catch (error) {
    console.error("Error unregistering push token:", error);
    return c.json({ error: "Failed to unregister push token" }, 500);
  }
});

// PUT /api/notifications/:id/read - Mark notification as read
notificationsRouter.put("/:id/read", async (c) => {
  const user = c.get("user");
  if (!user) {
    return c.json({ error: "Unauthorized" }, 401);
  }

  const notificationId = c.req.param("id");

  await db.notification.updateMany({
    where: { id: notificationId, userId: user.id },
    data: { read: true },
  });

  return c.json({ success: true });
});

// PUT /api/notifications/read-all - Mark all notifications as read
notificationsRouter.put("/read-all", async (c) => {
  const user = c.get("user");
  if (!user) {
    return c.json({ error: "Unauthorized" }, 401);
  }

  await db.notification.updateMany({
    where: { userId: user.id, read: false },
    data: { read: true },
  });

  return c.json({ success: true });
});

// Helper function to send push notifications to a user's devices
export async function sendPushNotification(
  userId: string,
  notification: {
    title: string;
    body: string;
    data?: Record<string, unknown>;
  }
) {
  try {
    // Get all push tokens for this user
    const pushTokens = await db.pushToken.findMany({
      where: { userId },
    });

    if (pushTokens.length === 0) {
      return;
    }

    // Send to Expo push notification service
    const messages = pushTokens.map((pt) => ({
      to: pt.token,
      sound: "default" as const,
      title: notification.title,
      body: notification.body,
      data: notification.data,
    }));

    // Send in chunks of 100
    const chunks = [];
    for (let i = 0; i < messages.length; i += 100) {
      chunks.push(messages.slice(i, i + 100));
    }

    for (const chunk of chunks) {
      try {
        await fetch("https://exp.host/--/api/v2/push/send", {
          method: "POST",
          headers: {
            "Content-Type": "application/json",
          },
          body: JSON.stringify(chunk),
        });
      } catch (error) {
        console.error("Error sending push notification chunk:", error);
      }
    }
  } catch (error) {
    console.error("Error sending push notifications:", error);
  }
}
